####### GAM based on Zero-One Inflated Beta

library(gamlss)

data1 = read.table("zzNeighborXwithHeader.txt", header=TRUE); 
head(data1)
##  1  2         3 4  5         6   7   8         9        9  10        11  12  13        14  15  16
##  x  y         F N  R        Fl  Nl  Rl        Fr       Nr  Rr        Fu  Nu  Ru        Fd  Nd  Rd
##1 3 38 1.0000000 0  0       NaN NaN NaN 0.8988368    0.000   0       NaN NaN NaN 1.0000000   0   0
##2 3 39 1.0000000 0  0       NaN NaN NaN 0.7132826    0.000  50 1.0000000   0   0       NaN NaN NaN
##3 4 38 0.8988368 0  0 0.8988368   0   0       NaN      NaN NaN       NaN NaN NaN 0.7132826   0  50

windows(); hist(data1$F); hist(log(data1$F+1)); (meanf = mean(data1$F))
windows(); hist(data1$N); hist(log(data1$N+1)); (meann = mean(data1$N))
windows(); hist(data1$R); hist(log(data1$R+1)); (meanr = mean(data1$R))

data2 = na.omit(data1)                  # data2 = data with complete neighbors
dim(data2)                              # n = 7912
data3 = na.omit(data1[, 3:5])           # data3 = data deleting neighbors in data1
dim(data3)                              # n = 8697
con = gamlss.control(trace=FALSE)

###########################################################
########### Table 5, Model B0,  n = 8697
###########################################################
beinf3 = gamlss(F~1, data=data3, family=BEINF)    # �����ϐ��Ȃ�
summary(beinf3)     # p = 4
#Global Deviance =  5644.787, AIC =  5652.787,  SBC =  5681.07 


########### Table 5, Model B1
beinf3 = gamlss(F~1  , sigma.fo=~1  , nu.fo=~N+R, tau.fo=~N+R, data=data3, family=BEINF)
summary(beinf3)     # p = 8
#Global Deviance =  2761.007, AIC =  2777.007,  SBC =  2833.573 

########### Table 5, Model B2
beinf3 = gamlss(F~N+R, sigma.fo=~N+R, nu.fo=~1  , tau.fo=~1  , data=data3, family=BEINF)
summary(beinf3)     # p = 8
#Global Deviance =  1494.174, AIC =  1510.174,  SBC =  1566.74 

########### Table 5, Model B3
beinf3 = gamlss(F~N+R, sigma.fo=~N+R, nu.fo=~N+R, tau.fo=~N+R, data=data3, family=BEINF)
summary(beinf3)     # p = 12
#Global Deviance =  -1389.606, AIC =  -1365.606,  SBC =  -1280.757 

########### Table 5, Model B4
beinf3c = gamlss(F~1, sigma.fo=~1, nu.fo=~log(N+1)+log(R+1), tau.fo=~log(N+1)+R, data=data3, family=BEINF)
summary(beinf3c)    # p = 8
#Global Deviance = 2645.943, AIC = 2661.943, SBC = 2718.508 

########### Table 5, Model B5
beinf3 = gamlss(F~log(N+1)+log(R+1), sigma.fo=~log(N+1)+log(R+1), nu.fo=~1, tau.fo=~1, data=data3, family=BEINF)
summary(beinf3)     # p = 8
#Global Deviance =  -1075.623, AIC =  -1059.623,  SBC =  -1003.057 


########### Table 5, Model B6
beinf3 = gamlss(F~log(N+1)+log(R+1), sigma.fo=~log(N+1)+log(R+1), nu.fo=~log(N+1)+log(R+1), tau.fo=~log(N+1)+log(R+1), data=data3, family=BEINF)
summary(beinf3)     # p = 12
#Global Deviance =  -3826.256, AIC =  -3802.256,  SBC =  -3717.408 



###### Covariates of Missing neighbors are substituted with corresponding mean values
data1 = read.table("zzNeighborXwithAvewithHeader.txt", header=TRUE); head(data1)
data2 = na.omit(data1)                  
dim(data2)                              
data3 = na.omit(data1[, 3:5])           
dim(data3)                              

########### Table 5, Model B6asterisk
beinf2 <- gamlss(F~log(N+1)+log(R+1)+log((Nr+Nl+Nu+Nd)/4+1)+log((Rr+Rl+Ru+Rd)/4+1), sigma.fo=~log(N+1)+log(R+1)+log((Nr+Nl+Nu+Nd)/4+1)+log((Rr+Rl+Ru+Rd)/4+1), nu.fo=~log(N+1)+log(R+1)+log((Nr+Nl+Nu+Nd)/4+1)+log((Rr+Rl+Ru+Rd)/4+1), tau.fo=~log(N+1)+log(R+1)+log((Nr+Nl+Nu+Nd)/4+1)+log((Rr+Rl+Ru+Rd)/4+1), data=data1, family=BEINF)
summary(beinf2)     # p = 20
## beinf2$df.fit = 20, beinf2$aic = -5850.077, beinf2$sbc = -5708.663

