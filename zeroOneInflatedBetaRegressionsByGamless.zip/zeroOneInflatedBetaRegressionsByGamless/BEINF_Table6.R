####### FittingWithCovariates_Poisson_NegtiveBinomial.R
####### ���ϗʂ�p����GLM

setwd("D:/MyDocuments/Text/Paper/TanakaForest/0-1inflated/Hiroshima/Gamlss")
data1 = read.table("zzNeighborXwithHeader.txt", header=TRUE); head(data1)
##  1  2         3 4  5         6   7   8         9        9  10        11  12  13        14  15  16
##  x  y         F N  R        Fl  Nl  Rl        Fr       Nr  Rr        Fu  Nu  Ru        Fd  Nd  Rd
##1 3 38 1.0000000 0  0       NaN NaN NaN 0.8988368    0.000   0       NaN NaN NaN 1.0000000   0   0
##2 3 39 1.0000000 0  0       NaN NaN NaN 0.7132826    0.000  50 1.0000000   0   0       NaN NaN NaN
##3 4 38 0.8988368 0  0 0.8988368   0   0       NaN      NaN NaN       NaN NaN NaN 0.7132826   0  50
##4 4 39 0.7132826 0 50 1.0000000   0   0 1.0000000    0.000  50 0.8988368   0   0       NaN NaN NaN
##5 4 41 1.0000000 0  0       NaN NaN NaN 0.4182420 2540.937   0       NaN NaN NaN       NaN NaN NaN
##6 5 39 1.0000000 0 50 1.0000000   0  50       NaN      NaN NaN       NaN NaN NaN       NaN NaN NaN

windows(); hist(data1$F); hist(log(data1$F+1)); (meanf = mean(data1$F))
windows(); hist(data1$N); hist(log(data1$N+1)); (meann = mean(data1$N))
windows(); hist(data1$R); hist(log(data1$R+1)); (meanr = mean(data1$R))

library(gamlss)

data2 = na.omit(data1)                  # data2: ���ӂ̃f�[�^�����ׂĂ�����Ă���f�[�^
dim(data2)                              # n = 7912
data3 = na.omit(data1[, 3:5])           # data3: ���S�̃f�[�^����
dim(data3)                              # n = 8697



################ Table 6  Model B7
for (i in 1:3){
 print(i)
 for (j in 1:3){
  beinf3log = gamlss(F~fp(log(N+1), 3)+fp(log(R+1), 3), sigma.fo=~fp(log(N+1), i)+fp(log(R+1), j), nu.fo=~1, tau.fo=~1, data=data3, control=con, family=BEINF)
  print(c(i, j, beinf3log$df.fit,  beinf3log$aic, beinf3log$sbc))
 }
}
#[1] 1
#[1]     1.000     1.000    20.000 -1633.834 -1492.420
#[1]     1.000     2.000    22.000 -1635.051 -1479.495
#[1]     1.000     3.000    24.000 -1631.364 -1461.666
#[1] 2
#[1]     2.000     1.000    22.000 -1639.699 -1484.143
#[1]     2.000     2.000    24.000 -1639.670 -1469.972
#[1]     2.000     3.000    26.000 -1635.938 -1452.099
#[1] 3
##[1]    3.000     1.000    24.000 -1685.071 -1515.374
#[1]     3.000     2.000    26.000 -1683.262 -1499.423
#[1]     3.000     3.000    28.000 -1679.378 -1481.397


################ Table 6  Model B8
for (i in 1:3){
 for (j in 1:3){
  for (k in 1:3){ print(k)
   for (l in 1:3){
    beinf3log = gamlss(F~fp(log(N+1),3)+fp(log(R+1),3), sigma.fo=~fp(log(N+1),3)+fp(log(R+1),1),
                  nu.fo=~fp(log(N+1),i)+fp(log(R+1),j),   tau.fo=~fp(log(N+1),k)+fp(log(R+1),l),
                  data=data3, control=con, family=BEINF)
    print(c(i, j, k, l, beinf3log$df.fit, beinf3log$aic, beinf3log$sbc))
   }
  }
 }
} ##  i     j     k     l df.fit   aic       sbc
#     1     1     1     1    32 -4683.025 -4456.761
#     1     1     1     2    34 -4808.747 -4568.342
#     1     1     1     3    36 -4812.077 -4557.531
#     1     1     2     1    34 -4683.026 -4442.621
#     1     1     2     2    36 -4808.668 -4554.122
#     1     1     2     3    38 -4812.185 -4543.497
#     1     1     3     1    36 -4682.498 -4427.951
#     1     1     3     2    38 -4808.468 -4539.780
#     1     1     3     3    40 -4811.677 -4528.848
#     1     2     1     1    34 -4711.511 -4471.106
#     1     2     1     2    36 -4831.373 -4576.826
#     1     2     1     3    38 -4836.909 -4568.221
#     1     2     2     1    36 -4711.504 -4456.957
#     1     2     2     2    38 -4831.277 -4562.589
#     1     2     2     3    40 -4836.982 -4554.153
#     1     2     3     1    38 -4710.980 -4442.292
#     1     2     3     2    40 -4831.077 -4548.247
#     1     2     3     3    42 -4836.486 -4539.516
#     1     3     1     1    36 -4714.456 -4459.910
#     1     3     1     2    38 -4834.591 -4565.903
#     1     3     1     3    40 -4839.990 -4557.161
#     1     3     2     1    38 -4714.448 -4445.760
#     1     3     2     2    40 -4834.495 -4551.666
##    1     3     2     3    42 -4840.063 -4543.092
#     1     3     3     1    40 -4713.924 -4431.095
#     1     3     3     2    42 -4834.296 -4537.325
#     1     3     3     3    44 -4839.570 -4528.458
#     2     1     1     1    34 -4680.283 -4439.878
#     2     1     1     2    36 -4807.407 -4552.860
#     2     1     1     3    38 -4810.776 -4542.088
#     2     1     2     1    36 -4680.288 -4425.742
#     2     1     2     2    38 -4807.347 -4538.659
#     2     1     2     3    40 -4810.908 -4528.078
#     2     1     3     1    38 -4679.756 -4411.069
#     2     1     3     2    40 -4807.132 -4524.303
#     2     1     3     3    42 -4810.385 -4513.414
#     2     2     1     1    36 -4710.161 -4455.615
#     2     2     1     2    38 -4830.591 -4561.903
#     2     2     1     3    40 -4836.410 -4553.581
#     2     2     2     1    38 -4710.161 -4441.473
#     2     2     2     2    40 -4830.513 -4547.684
#     2     2     2     3    42 -4836.506 -4539.536
#     2     2     3     1    40 -4709.632 -4426.803
#     2     2     3     2    42 -4830.30  -4533.33
#     2     2     3     3    44 -4836.001 -4524.889
#     2     3     1     1    38 -4712.058 -4443.370
#     2     3     1     2    40 -4832.745 -4549.915
#     2     3     1     3    42 -4838.373 -4541.402
#     2     3     2     1    40 -4712.057 -4429.228
#     2     3     2     2    42 -4832.665 -4535.695
#     2     3     2     3    44 -4838.467 -4527.355
#     2     3     3     1    42 -4711.529 -4414.558
#     2     3     3     2    44 -4832.456 -4521.344
#     2     3     3     3    46 -4837.967 -4512.713
#     3     1     1     1    36 -4677.403 -4422.856
#     3     1     1     2    38 -4804.357 -4535.669
#     3     1     1     3    40 -4807.727 -4524.898
#     3     1     2     1    38 -4677.395 -4408.707
#     3     1     2     2    40 -4804.284 -4521.455
#     3     1     2     3    42 -4807.842 -4510.871
#     3     1     3     1    40 -4676.869 -4394.039
#     3     1     3     2    42 -4804.075 -4507.104
#     3     1     3     3    44 -4807.324 -4496.212
#     3     2     1     1    38 -4706.629 -4437.941
#     3     2     1     2    40 -4827.193 -4544.363
#     3     2     1     3    42 -4832.983 -4536.012
#     3     2     2     1    40 -4706.621 -4423.791
#     3     2     2     2    42 -4827.099 -4530.128
#     3     2     2     3    44 -4833.062 -4521.950
#     3     2     3     1    42 -4706.094 -4409.123
#     3     2     3     2    44 -4826.905 -4515.793
#     3     2     3     3    46 -4832.578 -4507.325
#     3     3     1     1    40 -4708.354 -4425.525
#     3     3     1     2    42 -4829.025 -4532.055
#     3     3     1     3    44 -4834.744 -4523.632
#     3     3     2     1    42 -4708.345 -4411.375
#     3     3     2     2    44 -4828.937 -4517.825
#     3     3     2     3    46 -4834.824 -4509.571
#     3     3     3     1    44 -4707.818 -4396.706
#     3     3     3     2    46 -4828.829 -4503.575
#     3     3     3     3    48 -4834.340 -4494.945



################ Table 6  Model B9
sink("CubicSplineTable6B9.log") ## see log file
minaic = 0
for (i in 1:6){
 for (j in 1:6){ cat(sprintf("(i, j) = (%3d, %3d)\n", i,j))
  for (k in 1:6){
   for (l in 1:6){
    beinf3log = gamlss(F~cs(log(N+1), df=i)+cs(log(R+1), df=j), sigma.fo=~cs(log(N+1), df=k)+cs(log(R+1), df=l), 
                  nu.fo=~1, tau.fo=~1, data=data3, control=con, family=BEINF)
    if ( minaic > beinf3log$aic ){
     print(c(i, j, k, l, beinf3log$df.fit, beinf3log$aic, beinf3log$sbc))
     minaic = beinf3log$aic
    }
   }
  }
 }
} ##  i     j     k     l  df.fit      aic       sbc
sink()
##    1     6     6     5  29.73499 -1749.28679 -1539.03857



################ Table 6  Model B10
sink("CubicSplineTable6B10.log") ## see log file
minaic = 0
for (i in 1:6){
 for (j in 1:6){ cat(sprintf("(i, j) = (%3d, %3d)\n", i,j))
  for (k in 1:6){
   for (l in 1:6){
    beinf3log = gamlss(F~cs(log(N+1), df=1)+cs(log(R+1), df=6), sigma.fo=~cs(log(N+1), df=6)+cs(log(R+1), df=5),
                 nu.fo =~cs(log(N+1), df=i)+cs(log(R+1), df=j),   tau.fo=~cs(log(N+1), df=k)+cs(log(R+1), df=l),
                data=data3, control=con, family=BEINF)
    if ( minaic > beinf3log$aic ){
     print(c(i, j, k, l, beinf3log$df.fit, beinf3log$aic, beinf3log$sbc))
     minaic = beinf3log$aic
    }
   }
  }
 }
} ##  i     j     k     l  df.fit      aic       sbc
sink()
##    1     5     1     4  52.36261 -4922.42319 -4552.18115



################ Table 6  Model B10asterisk
data1 = read.table("zzNeighborXwithAvewithHeader.txt", header=TRUE); head(data1)
sink("CubicSplineTable6B10asterisk.log") ## see log file
minaic = 0
for (i in 1:6){
 for (j in 1:6){ cat(sprintf("(i, j) = (%3d, %3d)\n", i,j))
#  for (k in 1:6){
#   for (l in 1:6){
    beinf3log = gamlss(F~cs(log(N+1), df=1)+cs(log(R+1), df=6)+cs(log((Nl+Nr+Nu+Nd)/4+1),i)+cs(log((Rl+Rr+Ru+Rd)/4+1),j), sigma.fo=~cs(log(N+1), df=6)+cs(log(R+1), df=5)+cs(log((Nl+Nr+Nu+Nd)/4+1),2)+cs(log((Rl+Rr+Ru+Rd)/4+1),2), nu.fo=~cs(log(N+1), df=1)+cs(log(R+1), df=5)+cs(log((Nl+Nr+Nu+Nd)/4+1),2)+cs(log((Rl+Rr+Ru+Rd)/4+1),2), tau.fo=~cs(log(N+1), df=1)+cs(log(R+1), df=4)+cs(log((Nl+Nr+Nu+Nd)/4+1),2)+cs(log((Rl+Rr+Ru+Rd)/4+1),2), data=data1, control=con, family=BEINF)
    if ( minaic > beinf3log$aic ){
     print(c(i, j, beinf3log$df.fit, beinf3log$aic, beinf3log$sbc))
#     print(c(i, j, k, l, beinf3log$df.fit, beinf3log$aic, beinf3log$sbc))
     minaic = beinf3log$aic
#    }
#   }
  }
 }
} ##  i     j              df.fit      aic       sbc
sink()
##    2.0000     2.0000   104.4326 -6708.0864 -5969.6714
