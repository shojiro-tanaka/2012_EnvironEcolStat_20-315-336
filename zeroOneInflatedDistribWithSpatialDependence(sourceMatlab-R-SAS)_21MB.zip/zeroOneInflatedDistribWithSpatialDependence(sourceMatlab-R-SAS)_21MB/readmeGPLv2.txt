All source programs used in the manuscript:

  "Statistical modelling of forest coverage ratio based on 
  zero-one inflated distributions with spatial dependence,"

are in this subdirectories.

For processing details, please see the source programs.

These programs are basically free softwares unless otherwise noted;
you can redistribute it and/or modify them under the terms of the
GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option)
any later version.

These programs are distributed in the hope that they will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details. 

http://www.gnu.org/licenses/licenses.html

As for the intermediate files left for the purpose of algorithm
checks, please follow intructions of the original copyright holders.

Shojiro Tanaka, January, 2011
mailto:tanaka@cis.shimane-u.ac.jp
