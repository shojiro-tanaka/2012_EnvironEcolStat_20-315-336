#20100608 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# �ߖT��f�ւ̍œK��  N ==> -0.37 = power[10],  R ==> 0.95 = power[146]
# ���S��f�̍œK�Ђ��Đ���
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date()

#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZx    <- read.table("./dataPreparationAndData/zzSpatialData-rawNR-averagedNeighborValuesForQuadLoopEst.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")
dataZx    <- as.matrix(dataZx)
responseZ <- as.matrix(responseZ)
#ls()

powerN  = c( 0.15,  0.16,  0.17,  0.18,  0.19,  0.20,  0.21,  0.22,  0.23,  0.24,  0.25)
powerR  = c(-0.55, -0.54, -0.53, -0.52, -0.51, -0.5 , -0.49, -0.48, -0.47, -0.46, -0.45)
powerNx = c(-0.45, -0.44, -0.43, -0.42, -0.41, -0.4 , -0.39, -0.38, -0.37, -0.36, -0.35)
powerRx = c( 0.90,  0.91,  0.92,  0.93,  0.94,  0.95,  0.96,  0.97,  0.98,  0.99,  1.00)

minusTwoLogLikelihood <- array( 9999.9, dim=c( length(powerN ),length(powerR ),length(powerNx),length(powerRx) ) )

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

#�x�N�g����ʉ����`���f������
library(VGAM)

for (jRx in 1:length(powerRx)){

  pwRj <- powerRx[jRx]
  x4 <- dataZx[,13+jRx]
  
  for (jNx in 1:length(powerNx)){

    pwNj <- powerNx[jNx]
    x3 <- dataZx[,2+jNx]

    cat("\n\nNBD: Nx to power =, Rx to power =", pwNj, pwRj)
    
    for (iR in 1:length(powerR)){

      pwRi <- powerR[iR]
      x2 <- ( (dataZx[,2]+1.0)^pwRi - 1.0 )/pwRi
  
      for (iN in 1:length(powerN)){

        pwNi <- powerN[iN]
        x1 <- ( (dataZx[,1]+1.0)^pwNi - 1.0 )/pwNi

        cat("\nCenter: N to power =, R to power =", pwNi, pwRi)
        
        lReg = vglm(responseZ ~ x1+x2+x3+x4, family=multinomial)
	G    = fitted(lReg)
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[iN, iR, jNx, jRx] <- (-2*proSumZ)       # -2*log(Likihood)
        
      }
    }
  }
}

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerNValueNwithMinMinusTwoLogLikelihoodInArray <- powerN[arrayPosition[1,1]]
powerRValueRwithMinMinusTwoLogLikelihoodInArray <- powerR[arrayPosition[1,2]]
powerNxValueNwithMinMinusTwoLogLikelihoodInArray <- powerNx[arrayPosition[1,3]]
powerRxValueRwithMinMinusTwoLogLikelihoodInArray <- powerRx[arrayPosition[1,4]]

dateEnded <- date()
dateEnded
dateBegan

sink("./estimationOutputs/aicSpatial-byRawNR-byAveNeighborWithQuadLoops.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of, R to the power of:", powerNValueNwithMinMinusTwoLogLikelihoodInArray, powerRValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
cat("Nx to the power of, Rx to the power of:", powerNxValueNwithMinMinusTwoLogLikelihoodInArray, powerRxValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-byRawNR-byAveNeighborWithQuadLoops.bmp")
temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )

image(1:powerN, 1:powerN, minusTwoLogLikelihood[1:powerN,1:powerN,1,1], col=topo.colors(80))
image(1:powerN, 1:powerN, minusTwoLogLikelihood[1,1,1:powerN,1:powerN], col=topo.colors(80))

par(temppar)
dev.off()
