#2010-10-07, S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZ     <- read.table("./dataPreparationAndData/zzRawData.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

#sqrt(N)
#dataZ[,1] <- sqrt(dataZ[,1])
#
#sqrt(N+1)
dataZ[,1] <- sqrt(dataZ[,1]+1)
#
#log(N+1)
#dataZ[,1] <- log(dataZ[,1]+1.0)
#
#sqrt(R)
#dataZ[,2] <- sqrt(dataZ[,2])
#
#sqrt(R+1)
#dataZ[,2] <- sqrt(dataZ[,2]+1)
#
#log(R+1)
dataZ[,2] <- log(dataZ[,2]+1.0)

dataZ <-as.matrix(dataZ)
#colnames(dataZ) <- c("N","R")

responseZ <- as.matrix(responseZ)

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

#ls() 
#�x�N�g����ʉ����`���f������
library(VGAM)

#�t�@�C������9�ʂ�D����G�f�B�b�g����D
sink("./estimationOutputsForConfusionMatrix/aicIndependent-sqrt(N+1)_log(R+1).txt")
lReg  <-vglm(responseZ ~ dataZ, family=multinomial, trace=TRUE)
coe   <-coefficients(lReg)
G     = fitted(lReg)

proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
minusTwoLogLikelihood  <- (-2*proSumZ)

cat("\n-2log(L):", minusTwoLogLikelihood,"\n")

Gesti = max.col(G); Gtrue = responseZ+1
Confusion = matrix(0, 3, 3)
for (i in 1:length(Gesti)){
 Confusion[Gtrue[i], Gesti[i]] = Confusion[Gtrue[i], Gesti[i]] + 1
 }
Confusion   # Overall Accuracy = 0.9318156 �ƂȂ��OK
((Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))

coe
summary(dataZ)
warnings()

sink()
