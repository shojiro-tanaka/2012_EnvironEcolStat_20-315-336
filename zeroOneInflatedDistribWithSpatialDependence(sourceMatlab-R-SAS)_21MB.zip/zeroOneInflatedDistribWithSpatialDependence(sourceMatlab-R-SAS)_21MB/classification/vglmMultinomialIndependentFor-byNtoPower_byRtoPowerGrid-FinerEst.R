#20100603 S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))
dateBegan <- date()

#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZ     <- read.table("./dataPreparationAndData/zzRawData.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

responseZ <- as.matrix(responseZ)
#ls()

#�@���@���@��
#power of N, R
#��������"i","j"�i�p�ϊ��j�̓�d���[�v

powerN = 0.29 + c(-25:25)/2500.0  #(N, R) = (0.29, 0.61), new AIC = 7180.877
powerR = 0.61 + c(-25:25)/2500.0
#(powerN <- c(-50:75)/100)
#(powerR <- c(-100:300)/100)
powerN[subset(1:length(powerN), powerN==0)] = 0.001  # �p����̉ӏ����Ē�`
powerR[subset(1:length(powerR), powerR==0)] = 0.001  # �p����̉ӏ����Ē�`

AIC <- matrix(9999.9,nrow=length(powerN),ncol=length(powerR))
BIC <- matrix(9999.9,nrow=length(powerN),ncol=length(powerR))

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

dataP <- dataZ
dataZ =  dataZ + 1.0   # ���炩���߂P��ǉ����Ă���
dataP <- as.matrix(dataP)
minusTwoLogLikelihood <- matrix(9999.9,nrow=length(powerN),ncol=length(powerR))

#�x�N�g����ʉ����`���f������
library(VGAM); tmpmin = 10^10; 

for (j in 1:length(powerR)) {
    pwj <- powerR[j]
    dataP[,2] <- (dataZ[,2]^pwj - 1.0)/pwj
    
    for (i in 1:length(powerN)) {
        pwi <- powerN[i]
	cat("\nN to power, R to power:", pwi, ",", pwj, "\n")
	dataP[,1] <- (dataZ[,1]^pwi - 1.0)/pwi
	#colnames(dataP) <- c("N-power","R-power")
        lReg <- vglm(responseZ ~ dataP, family=multinomial)
	coe  <- coefficients(lReg)
	G    =  fitted(lReg)
        
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[i,j]  <- (-2*proSumZ)

	rm(proSumZ)
	rm(G)
	rm(coe)
	rm(lReg)

    }
}

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerValueNwithMinMinusTwoLogLikelihoodInArray <- powerN[arrayPosition[1,1]]
powerValueRwithMinMinusTwoLogLikelihoodInArray <- powerR[arrayPosition[1,2]]

dateEnded <- date()
sink("./estimationOutputs/aicIndependent-byNtoPower_byRtoPowerFinerEst.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of, R to the power of:", powerValueNwithMinMinusTwoLogLikelihoodInArray, powerValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-byNtoPower_byRtoPowerFinerEst.bmp")
#temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )
image(minusTwoLogLikelihood)
#par(temppar)
dev.off()

