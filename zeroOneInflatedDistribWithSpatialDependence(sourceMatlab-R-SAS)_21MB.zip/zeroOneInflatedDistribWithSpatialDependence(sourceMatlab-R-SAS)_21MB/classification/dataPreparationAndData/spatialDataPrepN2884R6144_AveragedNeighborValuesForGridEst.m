clear; diary off;
format long
  
%�אڍs��̓Ǎ���
load 'H8697.mat';  
neighborX = H8697;
clear H8697;

%�f�[�^�Ǎ��i"dataPreparation.r"�ō쐬������f�B���N�g�����j
load -ascii 'zzRawData.txt';
dataZ = zzRawData; clear zzRawData;

whos

%power(N,R - center pixel)
N2884 = ((dataZ(:,1)+1.0).^0.2884 - 1.0)./0.2884;
N     =   dataZ(:,1);
R6144 = ((dataZ(:,2)+1.0).^0.6144 - 1.0)./0.6144;
R     =   dataZ(:,2);

powerC = (-0.50:0.01:1.50);
dataNx = zeros(length(dataZ),length(powerC)); 
dataRx = zeros(length(dataZ),length(powerC)); 
xNavg  = zeros(length(dataZ),length(powerC)); 
xRavg  = zeros(length(dataZ),length(powerC)); 

for i=1:length(powerC)
  for j=1:length(dataZ)
    if powerC(i)==0.0 powerC(i)=0.001; end;
    dataNx(j,i)=((dataZ(j,1)+1.0).^powerC(i) - 1.0)./powerC(i);
    dataRx(j,i)=((dataZ(j,2)+1.0).^powerC(i) - 1.0)./powerC(i);
  end
end

xN  = neighborX * dataNx;
xR  = neighborX * dataRx;
tmp = sum(neighborX,1)';

for j=1:length(tmp)
  for i=1:length(powerC)
    if (tmp(j)>0)
      xNavg(j,i) = xN(j,i) ./ tmp(j);
      xRavg(j,i) = xR(j,i) ./ tmp(j);
    else
      xNavg(j,i) = 0;
      xRavg(j,i) = 0;
    end
  end
end

dataZx = full([N R N2884 R6144 xNavg xRavg tmp]);
save -ascii 'zzSpatialData-Npower0.2884_Rpower0.6144-averagedNeighborValuesForGridEst.txt' dataZx;

whos;
