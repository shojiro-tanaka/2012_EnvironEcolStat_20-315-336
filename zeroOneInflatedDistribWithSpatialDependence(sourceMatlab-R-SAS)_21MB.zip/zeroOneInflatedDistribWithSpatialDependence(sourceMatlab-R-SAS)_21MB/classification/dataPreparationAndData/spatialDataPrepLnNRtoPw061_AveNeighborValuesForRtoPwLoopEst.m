clear; diary off;
format long
  
%�אڍs��̓Ǎ���
load 'H8697.mat';  
neighborX = H8697;
clear H8697;

%�f�[�^�Ǎ��i"dataPreparation.r"�ō쐬������f�B���N�g�����j
load -ascii 'zzRawData.txt';
dataZ = zzRawData; clear zzRawData;

whos

%sqrt(N)
%dataZ(:,1) = sqrt(dataZ(:,1));
%
%log(N+1)
lnN = log(dataZ(:,1)+1.0);
%
%power(R-center pixel)
%R   =   dataZ(:,2);
R061 = ((dataZ(:,2)+1.0).^0.61 - 1.0)./0.61;

powerC = (-1.00:0.01:2.00);
dataRx = zeros(length(dataZ),length(powerC)); 
xNavg  = zeros(length(dataZ),1); 
xRavg  = zeros(length(dataZ),length(powerC)); 

for i=1:length(powerC)
  for j=1:length(dataZ)
    if powerC(i)==0.0 powerC(i)=0.001; end;
    dataRx(j,i)=((dataZ(j,2)+1.0).^powerC(i) - 1.0)./powerC(i);
  end
end

xN  = neighborX * lnN;
xR  = neighborX * dataRx;
tmp = sum(neighborX,1)';

for i=1:length(tmp)
  if (tmp(i)>0)
    xNavg(i) = xN(i) ./ tmp(i);
  else
    xNavg(i) = 0;
  end
end

for j=1:length(tmp)
  for i=1:length(powerC)
    if (tmp(j)>0)
      xRavg(j,i) = xR(j,i) ./ tmp(j);
    else
      xRavg(j,i)=0;
    end
  end
end

dataZx = full([lnN R061 xNavg xRavg tmp]);
% dim(xRavg): [length(dataZ),length(powerC)]; 

save -ascii 'zzSpatialData-log(N+1)_RtoPw061-AveragedNeighborsByRtoPowerLoop.txt' dataZx;

whos;
