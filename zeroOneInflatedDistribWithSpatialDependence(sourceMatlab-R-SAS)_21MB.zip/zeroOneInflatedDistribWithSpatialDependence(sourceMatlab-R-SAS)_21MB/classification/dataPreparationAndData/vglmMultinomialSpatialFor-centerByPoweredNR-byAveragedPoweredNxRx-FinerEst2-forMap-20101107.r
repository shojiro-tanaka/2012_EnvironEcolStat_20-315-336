#20101107 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# �ߖT��f�ւ̍œK��  N ==> -0.37 = power[10],  R ==> 0.95 = power[146]
# ���S��f�̍œK�Ђ��Đ���
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

#�f�[�^�Ǎ�
dataZx    <- read.table("zzSpatialData-byNRpowers-averagedNeighborValuesForQuadLoopSelectEst2forMap.txt")
responseXY <- read.table("zzResponseXY.txt")
dataZx    <- as.matrix(dataZx)
responseZ <- as.matrix(responseXY[,1])
#xyZ <- read.table("zzRawDataForMap.txt")
x <- responseXY[,2]
y <- responseXY[,3]
#ls()

powerN  = c( 0.195, 0.196, 0.197, 0.198, 0.199, 0.200, 0.201, 0.202, 0.203, 0.204, 0.205)
powerR  = c(-0.505,-0.504,-0.503,-0.502,-0.501,-0.500,-0.499,-0.498,-0.497,-0.496,-0.495)
powerNx = c(-0.405,-0.404,-0.403,-0.402,-0.401,-0.400,-0.399,-0.398,-0.397,-0.396,-0.395)
powerRx = c( 0.945, 0.946, 0.947, 0.948, 0.949, 0.950, 0.951, 0.952, 0.953, 0.954, 0.955)

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

#�x�N�g����ʉ����`���f������
library(VGAM)

  jRx = 8
  pwRj <- powerRx[jRx]
  x4 <- dataZx[,33+jRx]

    jNx = 7
    pwNj <- powerNx[jNx]
    x3 <- dataZx[,22+jNx]

    cat("\n\nNBD: Nx to power =, Rx to power =", pwNj, pwRj, "\n")

      iR = 8
      pwRi <- powerR[iR]
      x2 <- dataZx[,11+iR]

        iN = 8
        pwNi <- powerN[iN]
        x1 <- dataZx[,iN]

        cat("\nCenter: N to power =, R to power =", pwNi, pwRi, "\n")
        
        lReg = vglm(responseZ ~ x1+x2+x3+x4, family=multinomial)
	G    = fitted(lReg)
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood <- (-2*proSumZ)       # -2*log(Likihood)
        

cat("\nMin -2log(L):", minusTwoLogLikelihood,"\n")

Gesti = max.col(G); Gtrue = responseZ+1
Confusion = matrix(0, 3, 3)
for (i in 1:length(Gesti)){
 Confusion[Gtrue[i], Gesti[i]] = Confusion[Gtrue[i], Gesti[i]] + 1
 }
Confusion   # Overall Accuracy = 0.9318156 �ƂȂ��OK
((Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))

warnings()

dataMap <- cbind(Gesti,Gtrue, x, y)
write(t(dataMap),"xyDataForMapDrawSpatialModel.txt",ncolumns=4)
