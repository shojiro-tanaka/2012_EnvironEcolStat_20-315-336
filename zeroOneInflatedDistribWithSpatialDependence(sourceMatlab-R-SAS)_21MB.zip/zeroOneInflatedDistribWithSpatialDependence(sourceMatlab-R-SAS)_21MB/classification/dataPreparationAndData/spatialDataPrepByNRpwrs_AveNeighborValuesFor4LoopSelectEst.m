clear; diary off;
format long
  
%�אڍs��̓Ǎ���
load 'H8697.mat';  
neighborX = H8697;
clear H8697;

%�f�[�^�Ǎ��i"dataPreparation.r"�ō쐬������f�B���N�g�����j
load -ascii 'zzRawData.txt';
dataZ = zzRawData; clear zzRawData;

whos

powerN  = [ 0.15,  0.16,  0.17,  0.18,  0.19,  0.20,  0.21,  0.22,  0.23,  0.24,  0.25];
powerR  = [-0.55, -0.54, -0.53, -0.52, -0.51, -0.5 , -0.49, -0.48, -0.47, -0.46, -0.45];
powerNx = [-0.45, -0.44, -0.43, -0.42, -0.41, -0.4 , -0.39, -0.38, -0.37, -0.36, -0.35];
powerRx = [ 0.90,  0.91,  0.92,  0.93,  0.94,  0.95,  0.96,  0.97,  0.98,  0.99,  1.00];
dataNx = zeros(length(dataZ),length(powerNx)); 
dataRx = zeros(length(dataZ),length(powerRx)); 
xNavg  = zeros(length(dataZ),length(powerNx)); 
xRavg  = zeros(length(dataZ),length(powerRx)); 

for i=1:length(powerNx)
  for j=1:length(dataZ)
    N(j,i) = ((dataZ(j,1)+1.0).^powerN(i) - 1.0)./powerN(i);
    R(j,i) = ((dataZ(j,2)+1.0).^powerR(i) - 1.0)./powerR(i);
    dataNx(j,i) = ((dataZ(j,1)+1.0).^powerNx(i) - 1.0)./powerNx(i);
    dataRx(j,i) = ((dataZ(j,2)+1.0).^powerRx(i) - 1.0)./powerRx(i);
  end
end

xN  = neighborX * dataNx;
xR  = neighborX * dataRx;
tmp = sum(neighborX,1)';

for j=1:length(tmp)
  for i=1:length(powerNx)
    if (tmp(j)>0)
      xNavg(j,i) = xN(j,i) ./ tmp(j);
      xRavg(j,i) = xR(j,i) ./ tmp(j);
    else
      xNavg(j,i) = 0;
      xRavg(j,i) = 0;
    end
  end
end

dataZx = full([N R xNavg xRavg]);
save -ascii 'zzSpatialData-byNRpowers-averagedNeighborValuesForQuadLoopSelectEst.txt' dataZx;

whos;
