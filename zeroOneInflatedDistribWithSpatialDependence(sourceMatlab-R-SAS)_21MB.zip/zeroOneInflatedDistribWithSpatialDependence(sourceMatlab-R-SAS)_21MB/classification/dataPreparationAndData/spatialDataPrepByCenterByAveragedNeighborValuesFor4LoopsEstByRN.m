clear; diary off;
format long; format compact
  
%�אڍs��̓Ǎ���
load 'H8697.mat';  
neighborX = H8697;
clear H8697;

%�f�[�^�Ǎ��i"dataPreparation.r"�ō쐬������f�B���N�g�����j
load -ascii 'zzRawData.txt';
dataZ = zzRawData; clear zzRawData;

whos

powerC = (-1.50:0.01:1.50);
tmp = find(powerC == 0); powerC(tmp) = 0.0001;

dataN  = zeros(length(dataZ),length(powerC)); 
dataR  = zeros(length(dataZ),length(powerC)); 
dataNx = zeros(length(dataZ),length(powerC)); 
dataRx = zeros(length(dataZ),length(powerC)); 
xNavg  = zeros(length(dataZ),length(powerC)); 
xRavg  = zeros(length(dataZ),length(powerC)); 

for i=1:length(powerC)
  dataN(:,i) = ((dataZ(:,1)+1.0).^powerC(i) - 1.0)./powerC(i);
  dataR(:,i) = ((dataZ(:,2)+1.0).^powerC(i) - 1.0)./powerC(i);
end

xN  = neighborX * dataN;
xR  = neighborX * dataR;
tmp = sum(neighborX,1)';

for j=1:length(tmp)
  for i=1:length(powerC)
    if (tmp(j)>0)
      xNavg(j,i) = xN(j,i) ./ tmp(j);
      xRavg(j,i) = xR(j,i) ./ tmp(j);
    else
      xNavg(j,i) = 0;
      xRavg(j,i) = 0;
    end
  end
end

%dataZx = full([dataNx dataRx xNavg xRavg tmp]);
save -ascii 'zzPoweredN.txt'  dataN;
save -ascii 'zzPoweredR.txt'  dataR;
save -ascii 'zzPowerThenAveragedNx.txt' xNavg;
save -ascii 'zzPowerThenAveragedRx.txt' xRavg;
%save -ascii 'edNeighborValuesForFourFoldLoopEst.txt' dataZx;

whos

