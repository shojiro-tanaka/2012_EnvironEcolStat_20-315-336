clear; diary off;
format long
  
%�אڍs��̓Ǎ���
load 'H8697.mat';  
neighborX = H8697;
clear H8697;

%�f�[�^�Ǎ��i"dataPreparation.r"�ō쐬������f�B���N�g�����j
load -ascii 'zzRawDataForMap.txt';
dataZ = zzRawDataForMap; clear zzRawDataForMap;

whos

powerN  = [ 0.190, 0.192, 0.194, 0.196, 0.198, 0.200, 0.202, 0.204, 0.206, 0.208, 0.210];
powerR  = [-0.510,-0.508,-0.506,-0.504,-0.502,-0.500,-0.498,-0.496,-0.494,-0.492,-0.490];
powerNx = [-0.410,-0.408,-0.406,-0.404,-0.402,-0.400,-0.398,-0.396,-0.394,-0.392,-0.390];
powerRx = [ 0.940, 0.942, 0.944, 0.946, 0.948, 0.950, 0.952, 0.954, 0.956, 0.958, 0.960];
%selectN  = c( 0.190, 0.192, 0.194, 0.196, 0.198, 0.200, 0.202, 0.204, 0.206, 0.208, 0.210)
%selectR  = c(-0.510,-0.508,-0.506,-0.504,-0.502,-0.500,-0.498,-0.496,-0.494,-0.492,-0.490)
%selectNx = c(-0.410,-0.408,-0.406,-0.404,-0.402,-0.400,-0.398,-0.396,-0.394,-0.392,-0.390)
%selectRx = c( 0.940, 0.942, 0.944, 0.946, 0.948, 0.950, 0.952, 0.954, 0.956, 0.958, 0.960)
dataNx = zeros(length(dataZ),length(powerNx)); 
dataRx = zeros(length(dataZ),length(powerRx)); 
xNavg  = zeros(length(dataZ),length(powerNx)); 
xRavg  = zeros(length(dataZ),length(powerRx)); 

for i=1:length(powerNx)
  for j=1:length(dataZ)
    N(j,i) = ((dataZ(j,1)+1.0).^powerN(i) - 1.0)./powerN(i);
    R(j,i) = ((dataZ(j,2)+1.0).^powerR(i) - 1.0)./powerR(i);
    dataNx(j,i) = ((dataZ(j,1)+1.0).^powerNx(i) - 1.0)./powerNx(i);
    dataRx(j,i) = ((dataZ(j,2)+1.0).^powerRx(i) - 1.0)./powerRx(i);
  end
end

xN  = neighborX * dataNx;
xR  = neighborX * dataRx;
tmp = sum(neighborX,1)';

for j=1:length(tmp)
  for i=1:length(powerNx)
    if (tmp(j)>0)
      xNavg(j,i) = xN(j,i) ./ tmp(j);
      xRavg(j,i) = xR(j,i) ./ tmp(j);
    else
      xNavg(j,i) = 0;
      xRavg(j,i) = 0;
    end
  end
end

dataZx = full([N R xNavg xRavg dataZ(:,3:4)]);
save -ascii 'zzSpatialData-byNRpowers-averagedNeighborValuesForQuadLoopSelectEst2forMap.txt' dataZx;

whos;
