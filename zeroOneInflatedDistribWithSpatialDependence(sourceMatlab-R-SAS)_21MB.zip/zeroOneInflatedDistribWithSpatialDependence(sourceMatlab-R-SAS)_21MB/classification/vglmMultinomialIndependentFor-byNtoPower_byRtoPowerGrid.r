#20100527-20100603 S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date() 
#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZ     <- read.table("./dataPreparationAndData/zzRawData.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

responseZ <- as.matrix(responseZ)
#ls()

#�@���@���@��
#power of N, R
#��������"i","j"�i�p�ϊ��j�̓�d���[�v

#power <- (c(0:200)/100.0) - 0.5
power <- (c(0:5)/5.0)
#power <- (c(0:10)/10.0)
power[subset(1:length(power), power==0)] <- 0.001  # �p����̉ӏ����Ē�`

minusTwoLogLikelihood <- matrix(9999.9,nrow=length(power),ncol=length(power))

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

dataP <- dataZ
dataZ <- dataZ + 1.0
dataP <- as.matrix(dataP)

for (j in 1:length(power)) { #�������R�̙p

    pwj <- power[j]
    dataP[,2] <- ((dataZ[,2])^pwj - 1.0)/pwj
 
    for (i in 1:length(power)) { #�s������N�̙p

        pwi <- power[i]
	cat("\nN to power, R to power:", pwi, ",", pwj, "\n")
	dataP[,1] <- ((dataZ[,1])^pwi - 1.0)/pwi
	#colnames(dataP) <- c("N-power","R-power")

	#�x�N�g����ʉ����`���f������
	library(VGAM)

	lReg  <-vglm(responseZ ~ dataP, family=multinomial)
	coe   <-coefficients(lReg)
	G     = fitted(lReg)

	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[i,j]  <- (-2*proSumZ)

	rm(proSumZ)
	rm(G)
	rm(coe)
	rm(lReg)

    }
}

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerValueNwithMinTwoMinusLikelihoodInArray <- power[arrayPosition[1,1]]
powerValueRwithMinTwoMinusLikelihoodInArray <- power[arrayPosition[1,2]]

sink("./estimationOutputs/aicIndependent-byNtoPower_byRtoPowerTest.txt")
minMinusTwoLogLikelihood
arrayPosition
powerValueNwithMinTwoMinusLikelihoodInArray
powerValueRwithMinTwoMinusLikelihoodInArray
warnings()
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-byNtoPower_byRtoPowerTest.bmp")
#temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )
image(minusTwoLogLikelihood)
#par(temppar)
dev.off()

dateEnd <- date()
cat("\nCalculation has begun at", dateBegan, "\n")
cat("\nCalculation ended at", dateEnd, "\n")
