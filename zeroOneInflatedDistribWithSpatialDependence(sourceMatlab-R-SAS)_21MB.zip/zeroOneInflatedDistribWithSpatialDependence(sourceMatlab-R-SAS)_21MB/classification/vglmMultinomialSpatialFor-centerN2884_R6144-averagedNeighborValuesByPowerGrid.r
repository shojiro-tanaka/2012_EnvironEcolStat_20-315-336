#20100603 S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date() 
#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZx    <- read.table("./dataPreparationAndData/zzSpatialData-Npower0.2884_Rpower0.6144-averagedNeighborValuesForGridEst.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

dataZx    <- as.matrix(dataZx)
responseZ <- as.matrix(responseZ)
#ls()

#�@���@���@��
#power of N, R
#��������"i","j"�i�p�ϊ��j�̓�d���[�v

power <- (c(0:200)/100.0) - 0.5
#power <- (c(0:5)/5.0)
#power <- (c(0:10)/10.0)
power[subset(1:length(power), power==0)] <- 0.001  # �p����̉ӏ����Ē�`

minusTwoLogLikelihood <- matrix(9999.9,nrow=length(power),ncol=length(power))

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

dataPx <- dataZx
dataPx <- as.matrix(dataPx)

for (j in 1:length(power)) { #�������R�̙p

    rj <- power[j]
 
    for (i in 1:length(power)) { #�s������N�̙p

        ni <- power[i]
	cat("\nN to power, R to power:", ni,",", rj, "\n")
	dataPx <- dataZx[,c(3,4,4+i,4+length(power)+j)]

	#�x�N�g����ʉ����`���f������
	library(VGAM)

	lReg  <-vglm(responseZ ~ dataPx, family=multinomial)
	coe   <-coefficients(lReg)
	G     = fitted(lReg)

	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[i,j]  <- (-2*proSumZ)

	rm(proSumZ)
	rm(G)
	rm(coe)
	rm(lReg)

    }
}

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerValueNwithMinMinusTwoLogLikelihoodInArray <- power[arrayPosition[1,1]]
powerValueRwithMinMinusTwoLogLikelihoodInArray <- power[arrayPosition[1,2]]

dateEnded <- date()
sink("./estimationOutputs/aicSpatial-N2884_R6144-aveNeighborByGrid.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of, R to the power of:", powerValueNwithMinMinusTwoLogLikelihoodInArray, powerValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-N2884_byR6144-aveNeighborByGrid.bmp")
#temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )
image(minusTwoLogLikelihood)
#par(temppar)
dev.off()

