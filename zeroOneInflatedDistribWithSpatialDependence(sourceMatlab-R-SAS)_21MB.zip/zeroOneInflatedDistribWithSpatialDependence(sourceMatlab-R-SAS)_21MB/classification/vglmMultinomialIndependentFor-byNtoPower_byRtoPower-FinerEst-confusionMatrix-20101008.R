#20101008 S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZ     <- read.table("./dataPreparationAndData/zzRawData.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

responseZ <- as.matrix(responseZ)
#ls()

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

dataP <- dataZ
dataZ =  dataZ + 1.0   # ���炩���߂P��ǉ����Ă���
dataP <- as.matrix(dataP)

#�x�N�g����ʉ����`���f������
library(VGAM); 

    pwj = 0.6144
    dataP[,2] <- (dataZ[,2]^pwj - 1.0)/pwj
    
        pwi = 0.2884
	cat("\nN to power, R to power:", pwi, ",", pwj, "\n")
	dataP[,1] <- (dataZ[,1]^pwi - 1.0)/pwi
	#colnames(dataP) <- c("N-power","R-power")
        lReg <- vglm(responseZ ~ dataP, family=multinomial, trace=TRUE)
	coe  <- coefficients(lReg)
	G    =  fitted(lReg)
        
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood  <- (-2*proSumZ)

sink("./estimationOutputsForConfusionMatrix/aicIndependent-byNtoPower_byRtoPower-confusionMatrix.txt")

cat("\nMin -2log(L):", minusTwoLogLikelihood,"\n")
Gesti = max.col(G); Gtrue = responseZ+1
Confusion = matrix(0, 3, 3)
for (i in 1:length(Gesti)){
 Confusion[Gtrue[i], Gesti[i]] = Confusion[Gtrue[i], Gesti[i]] + 1
 }
Confusion   # Overall Accuracy = 0.9318156 �ƂȂ��OK
((Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))

coe
summary(dataZ)
warnings()

sink()
