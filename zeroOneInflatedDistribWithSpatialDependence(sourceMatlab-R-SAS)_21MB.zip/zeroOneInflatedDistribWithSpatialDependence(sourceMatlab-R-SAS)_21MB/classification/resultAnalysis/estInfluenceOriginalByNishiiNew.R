#20100611 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# 
# Optimal spatial model �̏ڍ׃`�F�b�N
# 1) Confusion matrix �̍쐬
# 2�jG0, G1 �ւ̊e�ϐ��̍v���x�� N vs Nx, R vs Rx, N+R vs Nx+Rx, N+Nx vs R+Rx
#    ��4�ʂ���l���C�O���t�����Ĕ�r

# �S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date()

# �f�[�^�Ǎ��i�T�u�f�B���N�g�����j
# ����2�ʂ܂ł̍œK�p�𒆐S�� 0.001���݂Ńv���X�}�C�i�X 0.05
# �͈̔͂řp�ϊ������f�[�^�̓ǂݍ���
dataZx    <- read.table("./dataPreparationAndData/zzSpatialData-byNRpowers-averagedNeighborValuesForQuadLoopSelectEst2.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")
dataZx    <- as.matrix(dataZx)
responseZ <- as.matrix(responseZ)
#ls()

powerN  = c( 0.195, 0.196, 0.197, 0.198, 0.199, 0.200, 0.201, 0.202, 0.203, 0.204, 0.205)
powerR  = c(-0.505,-0.504,-0.503,-0.502,-0.501,-0.500,-0.499,-0.498,-0.497,-0.496,-0.495)
powerNx = c(-0.405,-0.404,-0.403,-0.402,-0.401,-0.400,-0.399,-0.398,-0.397,-0.396,-0.395)
powerRx = c( 0.945, 0.946, 0.947, 0.948, 0.949, 0.950, 0.951, 0.952, 0.953, 0.954, 0.955)

#powerN  = c( 0.15,  0.16,  0.17,  0.18,  0.19,  0.20,  0.21,  0.22,  0.23,  0.24,  0.25)
#powerR  = c(-0.55, -0.54, -0.53, -0.52, -0.51, -0.5 , -0.49, -0.48, -0.47, -0.46, -0.45)
#powerNx = c(-0.45, -0.44, -0.43, -0.42, -0.41, -0.4 , -0.39, -0.38, -0.37, -0.36, -0.35)
#powerRx = c( 0.90,  0.91,  0.92,  0.93,  0.94,  0.95,  0.96,  0.97,  0.98,  0.99,  1.00)

minusTwoLogLikelihood <- array( 9999.9, dim=c( length(powerN ),length(powerR ),length(powerNx),length(powerRx) ) )

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

#�x�N�g����ʉ����`���f������
library(VGAM)

#for (jRx in 1:length(powerRx)){ # �œK�p�̃f�[�^�̂ݓǂݍ���
for (jRx in 8:8){             # powerRx = 0.952

  pwRj <- powerRx[jRx]
  x4 <- dataZx[,33+jRx]
  
  for (jNx in 7:7){           # powerNx = -0.399
#  for (jNx in 1:length(powerNx)){

    pwNj <- powerNx[jNx]
    x3 <- dataZx[,22+jNx]

    cat("\n\nNBD: Nx to power =, Rx to power =", pwNj, pwRj)
    
    for (iR in 8:8){
#    for (iR in 1:length(powerR)){

      pwRi <- powerR[iR]      # powerR = -0.498
      x2 <- dataZx[,11+iR]
  
#      for (iN in 1:length(powerN)){
      for (iN in 8:8){

        pwNi <- powerN[iN]    # powerN = 0.202
        x1 <- dataZx[,iN]

        cat("\nCenter: N to power =, R to power =", pwNi, pwRi)
        
        lReg = vglm(responseZ ~ x1+x2+x3+x4, family=multinomial)
	G    = fitted(lReg)
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	 (-2*proSumZ)       # -2*log(Likihood) = 2980.376 �ɂȂ��OK
#	minusTwoLogLikelihood[iN, iR, jNx, jRx] <- (-2*proSumZ)       # -2*log(Likihood)
        
      }                    #     [,1] [,2] [,3]
    }                      #[1,]  137    2   20
  }                        #[2,]    5 1543  165
}                          #[3,]    7  394 6424

Gesti = max.col(G); Gtrue = responseZ+1
Confusion = matrix(0, 3, 3)
for (i in 1:length(Gesti)){
 Confusion[Gtrue[i], Gesti[i]] = Confusion[Gtrue[i], Gesti[i]] + 1
 }
Confusion   # Overall Accuracy = 0.9318156 �ƂȂ��OK
((Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))

coe = coefficients(lReg); xx = c(-3500:800)/100; # y=x �̃O���t�쐬�p�f�[�^

# x1=>N, x2=>R, x3=>Nx, x4=>Rx
# �QG0�̃f�[�^�𔻕ʂ��邽�߁C�L���ȕϐ����r����D
# N vs Nx, R vs Rx, N+R vs Nx+Rx, N+Nx vs R+Rx
windows()
plot(coe[3]*x1[G0], coe[7]*x3[G0], main = "Contribution N vs Nx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(0,2), ylim=c(-2,0))

windows()
plot(coe[5]*x2[G0], coe[9]*x4[G0], main = "Contribution R vs Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))

windows()
plot(coe[3]*x1[G0] +coe[5]*x2[G0], coe[7]*x3[G0]+coe[9]*x4[G0], main = "Contribution Center vs NBD to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))

windows()
plot(coe[3]*x1[G0] +coe[7]*x3[G0], coe[5]*x2[G0]+coe[9]*x4[G0], main = "Contribution N+Nx vs R+Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2,2), ylim=c(-15,0))


# �O���t���t�@�C���ɕۑ�
bitmap("./estimationOutputs/ContributionNvsNx2G0.bmp")
plot(coe[3]*x1[G0], coe[7]*x3[G0], main = "Contribution N vs Nx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(0,2), ylim=c(-2,0))
dev.off()

bitmap("./estimationOutputs/ContributionRvsRx2G0.bmp")
plot(coe[5]*x2[G0], coe[9]*x4[G0], main = "Contribution R vs Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))
dev.off()

bitmap("./estimationOutputs/ContributionN_RvsNx_Rx2G0.bmp")
plot(coe[3]*x1[G0] +coe[5]*x2[G0], coe[7]*x3[G0]+coe[9]*x4[G0], main = "Contribution Center vs NBD to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))
dev.off()

bitmap("./estimationOutputs/ContributionN_NxvsR_Rx2G0.bmp")
plot(coe[3]*x1[G0] +coe[7]*x3[G0], coe[5]*x2[G0]+coe[9]*x4[G0], main = "Contribution N+Nx vs R+Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2,2), ylim=c(-15,0))
dev.off()


# �QG1�̃f�[�^�𔻕ʂ��邽�߁C�L���ȕϐ����r����D
windows()
plot(coe[4]*x1[G1], coe[ 8]*x3[G1], main = "Contribution N vs Nx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-8,0))

windows()
plot(coe[6]*x2[G1], coe[10]*x4[G1], main = "Contribution R vs Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2.7,0), ylim=c(0,10))

windows()
plot(coe[4]*x1[G1] +coe[ 6]*x2[G1], coe[8]*x3[G1]+coe[10]*x4[G1], main = "Contribution Center vs NBD to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-10,0), ylim=c(-4,8))

windows()
plot(coe[4]*x1[G1] +coe[ 8]*x3[G1], coe[6]*x2[G1]+coe[10]*x4[G1], main = "Contribution N+Nx vs R+Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-2,6))


# �O���t���t�@�C���ɕۑ�
bitmap("./estimationOutputs/ContributionNvsNx2G1.bmp")
plot(coe[4]*x1[G1], coe[ 8]*x3[G1], main = "Contribution N vs Nx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-8,0))
dev.off()

bitmap("./estimationOutputs/ContributionRvsRx2G1.bmp")
plot(coe[6]*x2[G1], coe[10]*x4[G1], main = "Contribution R vs Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2.7,0), ylim=c(0,10))
dev.off()

bitmap("./estimationOutputs/ContributionN_RvsNx_Rx2G1.bmp")
plot(coe[4]*x1[G1] +coe[ 6]*x2[G1], coe[8]*x3[G1]+coe[10]*x4[G1], main = "Contribution Center vs NBD to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-10,0), ylim=c(-4,8))
dev.off()

bitmap("./estimationOutputs/ContributionN_NxvsR_Rx2G1.bmp")
plot(coe[4]*x1[G1] +coe[ 8]*x3[G1], coe[6]*x2[G1]+coe[10]*x4[G1], main = "Contribution N+Nx vs R+Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-2,6))
dev.off()

