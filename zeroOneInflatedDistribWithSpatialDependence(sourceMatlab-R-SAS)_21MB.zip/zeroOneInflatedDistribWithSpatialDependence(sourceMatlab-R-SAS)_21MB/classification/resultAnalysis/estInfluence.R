#20100610 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# 
# Optimal spatial model �̏ڍ׃`�F�b�N
# 1) Confusion matrix �̍쐬
# 2�jG0, G1 �ւ̊e�ϐ��̍v���x�� N vs Nx, R vs Rx, N+R vs Nx+Rx, N+Nx vs R+Rx
#    ��4�ʂ���l���C�O���t�����Ĕ�r

Gesti = max.col(G); Gtrue = responseZ+1
Confusion = matrix(0, 3, 3)
for (i in 1:length(Gesti)){
 Confusion[Gtrue[i], Gesti[i]] = Confusion[Gtrue[i], Gesti[i]] + 1
 }
Confusion
(Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))
#     [,1] [,2] [,3]
#[1,]  137    2   20
#[2,]    5 1543  165
#[3,]    7  394 6424
#> ((Confusion[1,1] + Confusion[2,2] + Confusion[3,3])/length(Gesti))
# [1] 0.9318156
# = 0.9318156 = OverAll accuracy due to log(N+1) (R+1)^0.61 & (R_NBD+1)^0.94
# = 0.9318156 = OverAll accuracy due to Optimal spatial model

coe = coefficients(lReg); xx = c(-3500:800)/100; # y=x �̃O���t�쐬�p�f�[�^

# x1=>N, x2=>R, x3=>Nx, x4=>Rx
# �QG0�̃f�[�^�𔻕ʂ��邽�߁C�L���ȕϐ����r����D
# N vs Nx, R vs Rx, N+R vs Nx+Rx, N+Nx vs R+Rx
windows()
plot(coe[3]*x1[G0], coe[7]*x3[G0], main = "Contribution N vs Nx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(0,2), ylim=c(-2,0))

windows()
plot(coe[5]*x2[G0], coe[9]*x4[G0], main = "Contribution R vs Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))

windows()
plot(coe[3]*x1[G0] +coe[5]*x2[G0], coe[7]*x3[G0]+coe[9]*x4[G0], main = "Contribution Center vs NBD to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))

windows()
plot(coe[3]*x1[G0] +coe[7]*x3[G0], coe[5]*x2[G0]+coe[9]*x4[G0], main = "Contribution N+Nx vs R+Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2,2), ylim=c(-15,0))


# �O���t���t�@�C���ɕۑ�
bitmap("./estimationOutputs/ContributionNvsNx2G0.bmp")
windows()
plot(coe[3]*x1[G0], coe[7]*x3[G0], main = "Contribution N vs Nx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(0,2), ylim=c(-2,0))
dev.off()

bitmap("./estimationOutputs/ContributionRvsRx2G0.bmp")
plot(coe[5]*x2[G0], coe[9]*x4[G0], main = "Contribution R vs Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))
dev.off()

bitmap("./estimationOutputs/ContributionN_RvsNx_Rx2G0.bmp")
plot(coe[3]*x1[G0] +coe[5]*x2[G0], coe[7]*x3[G0]+coe[9]*x4[G0], main = "Contribution Center vs NBD to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-3.5,0), ylim=c(-12,0))
dev.off()

bitmap("./estimationOutputs/ContributionN_NxvsR_Rx2G0.bmp")
plot(coe[3]*x1[G0] +coe[7]*x3[G0], coe[5]*x2[G0]+coe[9]*x4[G0], main = "Contribution N+Nx vs R+Rx to G0")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2,2), ylim=c(-15,0))
dev.off()


# �QG1�̃f�[�^�𔻕ʂ��邽�߁C�L���ȕϐ����r����D
windows()
plot(coe[4]*x1[G1], coe[ 8]*x3[G1], main = "Contribution N vs Nx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-8,0))

windows()
plot(coe[6]*x2[G1], coe[10]*x4[G1], main = "Contribution R vs Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2.7,0), ylim=c(0,10))

windows()
plot(coe[4]*x1[G1] +coe[ 6]*x2[G1], coe[8]*x3[G1]+coe[10]*x4[G1], main = "Contribution Center vs NBD to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-10,0), ylim=c(-4,8))

windows()
plot(coe[4]*x1[G1] +coe[ 8]*x3[G1], coe[6]*x2[G1]+coe[10]*x4[G1], main = "Contribution N+Nx vs R+Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-2,6))


# �O���t���t�@�C���ɕۑ�
bitmap("./estimationOutputs/ContributionNvsNx2G1.bmp")
plot(coe[4]*x1[G1], coe[ 8]*x3[G1], main = "Contribution N vs Nx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-8,0))
dev.off()

bitmap("./estimationOutputs/ContributionRvsRx2G1.bmp")
plot(coe[6]*x2[G1], coe[10]*x4[G1], main = "Contribution R vs Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-2.7,0), ylim=c(0,10))
dev.off()

bitmap("./estimationOutputs/ContributionN_RvsNx_Rx2G1.bmp")
plot(coe[4]*x1[G1] +coe[ 6]*x2[G1], coe[8]*x3[G1]+coe[10]*x4[G1], main = "Contribution Center vs NBD to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-10,0), ylim=c(-4,8))
dev.off()

bitmap("./estimationOutputs/ContributionN_NxvsR_Rx2G1.bmp")
plot(coe[4]*x1[G1] +coe[ 8]*x3[G1], coe[6]*x2[G1]+coe[10]*x4[G1], main = "Contribution N+Nx vs R+Rx to G1")
par(new=T)
plot(xx, xx, type="l", col=c(2), axes=F, xlab='', ylab='', xlim=c(-8,0), ylim=c(-2,6))
dev.off()


