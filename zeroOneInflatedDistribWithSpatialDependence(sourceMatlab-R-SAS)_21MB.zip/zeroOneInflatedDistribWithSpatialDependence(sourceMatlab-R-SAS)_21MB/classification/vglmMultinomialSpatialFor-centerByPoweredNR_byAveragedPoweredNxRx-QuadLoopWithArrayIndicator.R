#20100606 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# �ߖT��f�ւ̍œK��  N ==> -0.37 = power[10],  R ==> 0.95 = power[146]
# ���S��f�̍œK�Ђ��Đ���
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date()
#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataN  = read.table("./dataPreparationAndData/PoweredN.txt")
dataR  = read.table("./dataPreparationAndData/PoweredR.txt")
dataNx = read.table("./dataPreparationAndData/PowerThenAveragedNx.txt")
dataRx = read.table("./dataPreparationAndData/PowerThenAveragedRx.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

dataN     = as.matrix(dataN , nrow=8697, ncol=301)
dataNx    = as.matrix(dataNx, nrow=8697, ncol=301)
dataR     = as.matrix(dataR , nrow=8697, ncol=301)
dataRx    = as.matrix(dataRx, nrow=8697, ncol=301)
responseZ = as.matrix(responseZ)

#�x�N�g����ʉ����`���f������
library(VGAM)

power <- c(-150:150)/100  # 301�v�f
power[which(power == 0)] = 0.001

# select = c(-0.75, -0.5, -0.25, -0.1, 0.1, 0.25, 0.5, 0.75, 1, 1.25)
# minMinusTwoLogLikelihood [1] 2983.322
# powerValueNwithMinMinusTwoLogLikelihoodInArray  [1]  0.25
# powerValueRwithMinMinusTwoLogLikelihoodInArray  [1] -0.5
# powerValueNxwithMinMinusTwoLogLikelihoodInArray [1] -0.5
# powerValueRxwithMinMinusTwoLogLikelihoodInArray [1]  1

# selectN  = c(0.1, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.5); 
# selectR  = c(-0.75, -0.65, -0.60, -0.55, -0.5, -0.45, -0.40, -0.35, -0.25)
# selectNx = c(-0.75, -0.65, -0.60, -0.55, -0.5, -0.45, -0.40, -0.35, -0.25)
# selectRx = c(0.75, 0.85, 0.90, 0.95, 1, 1.05, 1.1, 1.15, 1.25); 
# minMinusTwoLogLikelihood [1] 2980.383
# powerValueNwithMinMinusTwoLogLikelihoodInArray [1]  0.2
# powerValueRwithMinMinusTwoLogLikelihoodInArray [1] -0.5
# powerValueNxwithMinMinusTwoLogLikelihoodInArray[1] -0.4
# powerValueRxwithMinMinusTwoLogLikelihoodInArray[1]  0.95

# minMinusTwoLogLikelihood [1] 2980.383
# powerValueNwithMinMinusTwoLogLikelihoodInArray [1]  0.2
# powerValueRwithMinMinusTwoLogLikelihoodInArray [1] -0.5
# powerValueNxwithMinMinusTwoLogLikelihoodInArray[1] -0.4
# powerValueRxwithMinMinusTwoLogLikelihoodInArray[1]  0.95

selectN  = c( 0.15,  0.16,  0.17,  0.18,  0.19,  0.20,  0.21,  0.22,  0.23,  0.24,  0.25)
selectR  = c(-0.55, -0.54, -0.53, -0.52, -0.51, -0.5 , -0.49, -0.48, -0.47, -0.46, -0.45)
selectNx = c(-0.45, -0.44, -0.43, -0.42, -0.41, -0.4 , -0.39, -0.38, -0.37, -0.36, -0.35)
selectRx = c( 0.9 ,  0.91,  0.92,  0.93,  0.94,  0.95,  0.96,  0.97,  0.98,  0.99,  1   )

indN  = (selectN  + 1.5)*100 + 1; loopN  = length(selectN )
indR  = (selectR  + 1.5)*100 + 1; loopR  = length(selectR )
indNx = (selectNx + 1.5)*100 + 1; loopNx = length(selectNx)
indRx = (selectRx + 1.5)*100 + 1; loopRx = length(selectRx)
minusTwoLogLikelihood <- array(9999.9, dim=c(loopN, loopR, loopNx, loopRx))

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

for (iN in 1:loopN){
  x1 = dataN[, indN[iN]]
  cat("\n\nCenter: N to power =", selectN[iN])
#  if (select[iN] < 0.8){
  
  for (iR in 1:loopR){
    x2 = dataR[, indR[iR]]
    cat("\n Center: R to power =", selectR[iR])
    
    for (iNx in 1:loopNx){
      x3 = dataNx[, indNx[iNx]]
#      cat("\nNBD: Nx to power =", selectNx[iNx])
      
      for (iRx in 1:loopRx){
        x4 = dataRx[, indRx[iRx]]
#        cat("\nNBD: Rx to power =", selectRx[iRx])
        
        lReg = vglm(responseZ ~ x1+x2+x3+x4, family=multinomial)
	G    = fitted(lReg)
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[iN, iR, iNx, iRx] <- (-2*proSumZ)       # -2*log(Likihood)
#        }
      }
    }
  }
}

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerValueNwithMinMinusTwoLogLikelihoodInArray  <- selectN[arrayPosition[ 1,1]]
powerValueRwithMinMinusTwoLogLikelihoodInArray  <- selectR[arrayPosition[ 1,2]]
powerValueNxwithMinMinusTwoLogLikelihoodInArray <- selectNx[arrayPosition[1,3]]
powerValueRxwithMinMinusTwoLogLikelihoodInArray <- selectRx[arrayPosition[1,4]]


dateEnded <- date()
dateEnded
dateBegan

sink("./estimationOutputs/aicSpatial-N2884_R6144-aveNeighborByGrid.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of, R to the power of:", powerNValueNwithMinMinusTwoLogLikelihoodInArray, powerRValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-N2884_byR6144-aveNeighborByGrid.bmp")
#temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )
image(powerN, powerR, minusTwoLogLikelihood, col=topo.colors(80))

#par(temppar)
dev.off()

