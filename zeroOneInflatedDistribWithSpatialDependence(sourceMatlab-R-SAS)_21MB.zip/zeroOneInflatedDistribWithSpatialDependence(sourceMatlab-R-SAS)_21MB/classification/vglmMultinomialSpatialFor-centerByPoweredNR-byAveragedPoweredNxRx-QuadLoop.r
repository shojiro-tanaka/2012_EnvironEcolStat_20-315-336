#20100607 S.Tanaka and R.Nishii for the analysis of data with 0,1-inflated distribution
# �ߖT��f�ւ̍œK��  N ==> -0.37 = power[10],  R ==> 0.95 = power[146]
# ���S��f�̍œK�Ђ��Đ���
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date()
#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataN  = read.table("./dataPreparationAndData/zzPoweredN.txt")
dataR  = read.table("./dataPreparationAndData/zzPoweredR.txt")
dataNx = read.table("./dataPreparationAndData/zzPowerThenAveragedNx.txt")
dataRx = read.table("./dataPreparationAndData/zzPowerThenAveragedRx.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")

dataN     = as.matrix(dataN)
dataNx    = as.matrix(dataNx)
dataR     = as.matrix(dataR)
dataRx    = as.matrix(dataRx)
responseZ = as.matrix(responseZ)

#�x�N�g����ʉ����`���f������
library(VGAM)

power <- c(-150:150)/100  # 301�v�f
power[which(power == 0)] <- 0.001

iteration <- 10 
interval  <- round(301/iteration); 
selectArrayPosition <- interval*c(1:iteration)
minusTwoLogLikelihood <- array(9999.9, dim=c(iteration, iteration, iteration, iteration))

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

for (iRx in 1:iteration){
  x4 = dataRx[, interval*iRx]
  
  for (iNx in 1:iteration){
    x3 = dataNx[, interval*iNx]
    cat("\n\nNBD: Nx to power =, Rx to power =", power[interval*iNx], power[interval*iRx])
    
    for (iR in 1:iteration){
      x2 = dataR[, interval*iR]
      
      for (iN in 1:iteration){
        x1 = dataN[, interval*iN]
        cat("\nCenter: N to power =, R to power =", power[interval*iN], power[interval*iR])
        
        lReg = vglm(responseZ ~ x1+x2+x3+x4, family=multinomial)
	G    = fitted(lReg)
	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[iN, iR, iNx, iRx] <- (-2*proSumZ)       # -2*log(Likihood)
        
      }
    }
  }
}
# 743�b / (17 * 21) �ʂ� = 2.081232 sec
# 722�b / (17 * 21) �ʂ� = 2.022409 sec

minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerNValueNwithMinMinusTwoLogLikelihoodInArray <- power[interval*arrayPosition[1,1]]
powerRValueRwithMinMinusTwoLogLikelihoodInArray <- power[interval*arrayPosition[1,2]]
powerNxValueNwithMinMinusTwoLogLikelihoodInArray <- power[interval*arrayPosition[1,3]]
powerRxValueRwithMinMinusTwoLogLikelihoodInArray <- power[interval*arrayPosition[1,4]]

dateEnded <- date()
dateEnded
dateBegan

sink("./estimationOutputs/aicSpatial-byPoweredNR-byAveragedPoweredNxRx-QuadLoop.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of, R to the power of:", powerNValueNwithMinMinusTwoLogLikelihoodInArray, powerRValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
cat("Nx to the power of, Rx to the power of:", powerNxValueNwithMinMinusTwoLogLikelihoodInArray, powerRxValueRwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-byPoweredNR-byAveragedPoweredNxRx-QuadLoop.bmp")
temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )

image(1:iteration, 1:iteration, minusTwoLogLikelihood[1:iteration,1:iteration,1,1], col=topo.colors(80))
image(1:iteration, 1:iteration, minusTwoLogLikelihood[1,1,1:iteration,1:iteration], col=topo.colors(80))

par(temppar)
dev.off()

