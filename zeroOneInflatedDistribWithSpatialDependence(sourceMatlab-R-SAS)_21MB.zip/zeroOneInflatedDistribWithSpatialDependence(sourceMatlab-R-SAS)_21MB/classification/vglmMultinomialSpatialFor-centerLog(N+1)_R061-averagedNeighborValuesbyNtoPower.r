#20100606 S.Tanaka for the analysis of data with 0,1-inflated distribution
#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dateBegan <- date() 
#�f�[�^�Ǎ��i�T�u�f�B���N�g�����j
dataZx    <- read.table("./dataPreparationAndData/zzSpatialData-log(N+1)_RtoPw061-AveragedNeighborsByNtoPowerLoop.txt")
responseZ <- read.table("./dataPreparationAndData/zzResponse.txt")
#�Ή�����Matlab�v���O����
#dataZx = full([lnN R061 xNavg xRavg tmp]);
#% dim(xNavg): [length(dataZ),length(powerC)]; 

dataZx    <- as.matrix(dataZx)
responseZ <- as.matrix(responseZ)
#ls()

#�@���@���@��
#power of N, R
#��������"i"�̃��[�v

power <- (c(0:300)/100.0) - 1.0
#power <- (c(0:5)/5.0)
#power <- (c(0:10)/10.0)
power[subset(1:length(power), power==0)] <- 0.001  # �p����̉ӏ����Ē�`

minusTwoLogLikelihood <- matrix(9999.9,nrow=length(power),ncol=1)

G0 = subset(1:length(responseZ), responseZ==0)
G1 = subset(1:length(responseZ), responseZ==1)
G2 = subset(1:length(responseZ), responseZ==2)

dataPx <- dataZx
dataPx <- as.matrix(dataPx)

    for (i in 1:length(power)) {

        ni <- power[i]
	dataPx <- dataZx[,c(1,2,2+i,304)]
	cat("\nN to power:", ni, "\n")

	#�x�N�g����ʉ����`���f������
	library(VGAM)

	lReg  <-vglm(responseZ ~ dataPx, family=multinomial)
	coe   <-coefficients(lReg)
	G     = fitted(lReg)

	proSumZ <- sum( log(G[G0,1]) ) + sum( log(G[G1,2]) ) + sum( log(G[G2,3]) )
	minusTwoLogLikelihood[i,1]  <- (-2*proSumZ)

	rm(proSumZ)
	rm(G)
	rm(coe)
	rm(lReg)

    }


minMinusTwoLogLikelihood <- min(minusTwoLogLikelihood)
arrayPosition <- (which(minusTwoLogLikelihood==min(minusTwoLogLikelihood), arr.ind=TRUE))
powerValueNwithMinMinusTwoLogLikelihoodInArray <- power[arrayPosition[1,1]]

dateEnded <- date()
sink("./estimationOutputs/aicSpatial-centerLog(N+1)_R061-aveNeighborsByNtoPwrLoop.txt")
cat("\nMin -2log(L):", minMinusTwoLogLikelihood,"\n")
cat("Array position:", arrayPosition,"\n")
cat("N to the power of:", powerValueNwithMinMinusTwoLogLikelihoodInArray,"\n\n")
warnings()
cat("\nCalculation has begun at :", dateBegan,"\n")
cat("Calculation ended at     :", dateEnded,"\n")
sink()

bitmap("./estimationOutputs/minusTwoLogLikelihood-centerLog(N+1)_byR061-aveNeighborsByNtoPwrLoop.bmp")
#temppar <- par( mfrow=c(2,1),mar=c(2,2,1,2) )
plot(power,minusTwoLogLikelihood)
#par(temppar)
dev.off()

