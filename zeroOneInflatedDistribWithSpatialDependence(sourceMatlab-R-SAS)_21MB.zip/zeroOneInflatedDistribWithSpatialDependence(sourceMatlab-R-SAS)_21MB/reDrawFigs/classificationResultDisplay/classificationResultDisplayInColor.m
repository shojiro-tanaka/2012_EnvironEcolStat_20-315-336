diary off; clear;

load xyDataForMapDrawIndependentModel.txt;
load xyDataForMapDrawSpatialModel.txt;

fIndepen = xyDataForMapDrawIndependentModel(:,1);
fSpatial = xyDataForMapDrawSpatialModel(:,1);
fTrue    = xyDataForMapDrawIndependentModel(:,2);
%fTrue    = xyDataForMapDrawSpatialModel(:,2);
x = xyDataForMapDrawSpatialModel(:,3);
y = xyDataForMapDrawSpatialModel(:,4);
fDiff = fSpatial - fIndepen;

maxX=max(x)
minX=min(x)
maxY=max(y)
minY=min(y)

independentF  = zeros(maxX,maxY);
spatialF      = zeros(maxX,maxY);
trueF         = zeros(maxX,maxY);

count = 0;
for j = 1:maxY
  for i = 1:maxX
  site = find( x(:) == i & y(:) == j );
  if isfinite(site)
    count = count + 1;
    independentF(i,j) = fIndepen(site);
    spatialF(i,j)     = fSpatial(site);
    trueF(i,j)        = fTrue(site);
  else
    independentF(i,j)= NaN;
    spatialF(i,j)    = NaN;
    trueF(i,j)       = NaN;
    %fprintf('There is no pixel with (%3d, %3d)\n', i, j)
  end
  clear site;
  end
end
fprintf('\nData Size of the target dataset = %d\n', count)

%%% colortable manual-handling maybe needed %%%
fColor=[0.5 0 0;0.0:0.5:1.0;zeros(1,3)]';
%fColor=[zeros(1,3);0.0:0.5:1.0;zeros(1,3)]';
colormap(brighten(fColor,0.1));
mapF=colormap;
colormap(mapF)

figure,h=surf(1:maxY,1:maxX,independentF);
figure,h=surf(1:maxY,1:maxX,spatialF);
figure,h=surf(1:maxY,1:maxX,trueF);

