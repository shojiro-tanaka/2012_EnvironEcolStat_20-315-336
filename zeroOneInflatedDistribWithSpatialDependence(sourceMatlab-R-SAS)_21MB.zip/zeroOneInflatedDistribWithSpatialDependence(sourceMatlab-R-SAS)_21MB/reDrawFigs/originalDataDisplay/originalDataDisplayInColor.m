clear;

load F.data;
load N.data;
load R.data;

%for j=1:140
%  for i=1:120
%      if ( F(j,i) > 1 | R(j,i) == 999 | N(j,i) > 99999)
%         F(j,i) = -3;
%         N(j,i) = -100000;
%         R(j,i) = 58000;
%      end
%   end
%end

Fmax = max(max(F))
Nmax = max(max(N))
Rmax = max(max(R))

fColor=[zeros(1,101);0.0:0.01:1.0;zeros(1,101)]';
figure(1)
colormap(brighten(fColor,0.1));
mapF=colormap;
mapF(101,:)=[1.0,1.0,1.0];
colormap(mapF)
set(gca,'Units','normalized','Position',[0 0 1 1])
image(80*F)

figure(2)
colormap(brighten(hot(256),0.3));
mapN=colormap;
%mapN(1,:)=[1.0,1.0,1.0];
%colormap(mapN)
set(gca,'Units','normalized','Position',[0 0 1 1])
image(N/10)

cool2=cool(256);
%cool2(1,:)=[0 0 0];
figure(3)
colormap(brighten(cool2,0.1));
mapR=colormap;
mapR(256,:)=[1.0,1.0,1.0];
colormap(mapR)
set(gca,'Units','normalized','Position',[0 0 1 1])
image(R/2)
