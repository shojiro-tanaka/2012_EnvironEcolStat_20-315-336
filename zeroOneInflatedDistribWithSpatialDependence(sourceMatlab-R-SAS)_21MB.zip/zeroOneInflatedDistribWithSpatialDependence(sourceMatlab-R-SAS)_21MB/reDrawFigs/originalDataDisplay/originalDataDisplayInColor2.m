clear;

load F.data;
load N.data;
load R.data;

%for j=1:140
%  for i=1:120
%      if ( F(j,i) > 1 | R(j,i) == 999 | N(j,i) > 99999)
%         F(j,i) = -3;
%         N(j,i) = -100000;
%         R(j,i) = 58000;
%      end
%   end
%end

Fmax = max(max(F))
Nmax = max(max(N))
Rmax = max(max(R))

figure(1)
colormap(brighten(hot(256),0.3));
mapN=colormap;
%mapN(1,:)=[1.0,1.0,1.0];
%colormap(mapN)
set(gca,'Units','normalized','Position',[0 0 1 1])
image(25*log(N+1))

