set(gca,'Units','normalized','Position',[0 0 1 1])
