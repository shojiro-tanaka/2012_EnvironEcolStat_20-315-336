clear;
diary off;

%%% (data load) %%%
load 'H8697b.mat'; whos
F = X( :, 3);
N = X( :, 4);
R = X( :, 5);
clear X;
%%% /(data load) %%%


%%%  (forest areal rate == 0 or 1) %%%
L0 = F ==0.0; %sum(L0):159
L1 = F ==1.0; %sum(L1):1713
%%% /(forest areal rate == 0 or 1) %%%

%H8697�͗אڍs��
xF0  = H8697 * L0; 
xF1  = H8697 * L1;
tmp = sum(H8697,1); tmp = tmp';
clear L0 L1;

%check = [xF0, xF1, tmp];
%for i=1:dSizeAll
%  if (check(i,3)<check(i,1)) or (check(i,3)<check(i,2))
%    disp('error!')
%  end
%end

XX = [F, N, R, xF0, xF1];
clear F N R xF0 xF1;

%%%  (0 < forest areal rate < 1) %%%
L  = XX(:,1) < 1;
XX = XX(L,:); clear L;
L  = XX(:,1) > 0;
XX = XX(L,:); clear L;
L  = XX(:,2) > 0;
XX = XX(L,:); clear L;
dSize4logitNonZeroN  = length(XX) % (0 < F < 1, 0 < N)
%%% /(0 < forest areal rate < 1) %%%

save 'zzSpatialDataWithF0F1NeighborNumNonZeroN.mat' dSize4logitNonZeroN XX;

% D0, D1 �̉�f���אڂ��Ă���p�x���z
pair = zeros(5,5);            % pair(1,1) = 1806 �� 1806 �̒��S��f��
for i = 1:length(XX)          % 4��D2�̉�f�Ɉ͂܂�Ă��邱�Ƃ�\��
 pair(XX(i,4)+1, XX(i,5)+1) = pair(XX(i,4)+1, XX(i,5)+1) + 1;
end                           
pair                          
sum(pair) 
sum(pair')'
sum(pair(:)) 
