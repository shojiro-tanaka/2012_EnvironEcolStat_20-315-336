Refer to formulation of H4logit.mat and others in (note data size different: 0 < F < 1):

sourceRelease\estimations\testFields\hiroshima\zz_spatialStepFunctions\dataset2 (include F=1)
(http://www.cis.shimane-u.ac.jp/~tanaka/openProgs/sourceRelease-TGRSvol47(2009)pp2617-2626.zip)


(I:\TANAKA\tanaka\myDOCs\academicDocs\SPIE\2005_Bruges_Belgium\hiroshima\logitHiroshima_by_Matlab_4_bestModels\spatial)