function [mse, g, h] = funK1bL3TestGradObj(beta)
global F logN R dataSize sse mse;

%clear k;
for k = 2:length(beta)
   if beta(k) < 0
      beta(k) = 1e-6*abs(randn(1));
   end
end


if beta(2) > 0.01
   beta(2) = 1e-6*abs(randn(1));
end
if beta(3) > 0.01
   beta(3) = 1e-6*abs(randn(1));
end

%%%%%%
block1=exp(beta(7)-beta(8)*(R.^beta(9)));
%%%%%%
B = ...
log( (F+beta(2))./(1.0-F+beta(3)) ) ...
-( beta(1) - beta(4)*logN.^beta(5) ...
  +beta(6)*( 1.0./(1.0+block1) - 1.0/(1.0+exp(beta(7))) ) ...
 ); 

sse = B'*B;
if sse < 0
   disp('sse negative!');
end
%clear B;

mse = sse/dataSize;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
g(1) =  1.0 ;
g(2) =  1.0./( F + beta(2) ) ;
g(3) =  1.0./(1.0 - F + beta(3)) ;
g(4) = -logN^beta(5) ;
g(5) = -beta(4)*logN.^beta(5)*log(logN) ;
g(6) =  1.0./(1.0 + block1)- 1.0./(1.0+exp(beta(7))) ;
g(7) =  beta(6)*block1./((1.0+block1).^2) - ...
         beta(6)*exp(beta(7))/((1.0+exp(beta(7))).^2) ;
g(8) =  beta(6)*block1*(R.^beta(9))./((1.0+block1).^2) ;
g(9) =  beta(6)*beta(8)*block1*(R.^beta(9))*log(R)./((1.0+block1).^2) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
