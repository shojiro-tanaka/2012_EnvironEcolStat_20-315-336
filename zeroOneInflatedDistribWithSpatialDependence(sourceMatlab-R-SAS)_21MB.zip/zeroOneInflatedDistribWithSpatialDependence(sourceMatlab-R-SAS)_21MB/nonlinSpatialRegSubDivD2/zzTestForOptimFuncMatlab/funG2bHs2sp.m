function mse = funG2bHs2sp(beta) 
global logitF logN R dataSize sse mse W; 
 
clear k; 
for k = 2:length(beta); 
   if beta(k) < 0 
      beta(k) = 1e-6*abs(randn(1)); 
   end 
end 
 
B = zeros(dataSize,1); 
B = beta(1) + ... 
    beta(2) * ... 
   - ( 1.0./(1.0+exp(beta(3)-beta(4)*(logN.^beta(5)))) ... 
      -1.0./(1.0+exp(beta(3))) ); 
 
clear k; 
for k = 1:dataSize 
   if R(k) > beta(6) 
      B(k) = B(k) + beta(7)*log( R(k)/beta(6) ) ; 
   end 
end 
clear k; 
 
C = logitF - B; 
 
sse = C'*W*C; 
 
if sse < 0 
   disp('sse negative!'); 
end

mse = sse/dataSize;
 
%%% eof %%% 