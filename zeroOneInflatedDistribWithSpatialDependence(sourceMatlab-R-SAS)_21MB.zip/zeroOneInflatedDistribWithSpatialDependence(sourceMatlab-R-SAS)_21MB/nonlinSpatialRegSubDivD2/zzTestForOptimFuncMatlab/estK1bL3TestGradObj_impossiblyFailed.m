%estK1bL3.m 
% see %% applied FUNCTION %%% 
%2010-06-25
%format compact; format long; 
clear; 
global F logN R dataSize sse mse; 
 
 
diary off 
disp('*** erase former log-file. ok? (hit any-key) ***') 
disp('(this matlab program list will be output to log)') 
pause 
 
!erase estK1bL3TestGradObj.log; 
%!rm estK1bL3TestGradObj.log; 
diary('estK1bL3TestGradObj.log'); 
!type estK1bL3TestGradObj.m; 
%!cat estK1bL3TestGradObj.m; 
disp('      ') 
disp('      ') 
disp('%%% applied FUNCTION %%%') 
disp('      ') 
!type funK1bL3TestGradObj.m; 
%!cat funK1bL3TestGradObj.m; 
disp('      ') 
disp('      ') 
disp('*** actual execution begins, ok? (hit any-key) ***') 
pause 
disp('      ') 

%options=optimset('Display','iter');  
options=optimset('GradObj','on','Display','iter');  
options=optimset('LargeScale','on','Display','iter');  
options=optimset(options,'MaxFunEvals',4000);  
options=optimset(options,'MaxIter',500);  
options=optimset('TolX',1e-10);  
options=optimset(options,'TolFun',1e-8);  

%load 'vectors4nLinRegression.mat'; 
%dataSize = length(F) 
%clear dr00 dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15 ... 
%      dn00 dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08; 

load 'H4logit.mat'; whos 
F = X( :, 3);  
N = X( :, 4);  
R = X( :, 5);  
logitF = log( F ./ (1-F) );  
logN   = log( N + 1 );  
dataSize = dsize  
clear dsize dim_org N;  
  
beta0=[... 
   0.000; 
   1.0e-7; 
   1.0e-9; 
   0.001; 
   0.98; 
   6.3; 
   5.0e-8; 
   0.001; 
   1.1 ... 
]  

[beta, fval, exitflag, output, grad, hessian] = fminunc(@funK1bL3TestGradObj, beta0, options) 
 
format long; 
sse 
dataSize 
mse 
fval 
 
aic=dataSize*log(mse)+2*sum(log((F+beta(2)).*(1.0-F+beta(3))))+2*(length(beta)+1) 
beta

%save 'estK1bL3.mat' beta;  ... 
%                     aic; fval; mse; sse; dataSize; exitflag;
diary off 
