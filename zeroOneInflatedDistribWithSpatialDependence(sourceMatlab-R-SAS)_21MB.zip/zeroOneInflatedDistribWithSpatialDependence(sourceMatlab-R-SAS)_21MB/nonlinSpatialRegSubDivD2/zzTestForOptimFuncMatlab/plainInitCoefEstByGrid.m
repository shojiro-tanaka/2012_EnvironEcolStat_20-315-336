%���̃��[�`���́CR����`�σ��f���̍ŏ�MSE�ƕꐔ�����߂�
%�i�q�T���t
%beta(1),beta(2),beta(3),beta(4),beta(5)
%F = exp( -beta(1)*( R+beta(5) ).^(-beta(4))*N.^beta(2) ) -beta(3) );
%2002-09-16
%format compact; format long;
clear;
t = clock;
global F N R dataSize sse mse;

diary off
disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase plainEstCoefGrid.log;
%!rm plainEstCoefGrid.log;
diary('plainEstCoefGrid.log');
!type plainEstCoefGrid.m;
%!cat plainEstCoefGrid.m;
disp('      ')
disp('      ')
disp('%%% FUNCTION applied %%%')
disp('      ')
!type funCoef.m;
%!cat funCoef.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

%options=optimset('Display','iter');
options=optimset('LargeScale','off','Display','iter');
options=optimset(options,'MaxFunEvals',200000);
options=optimset(options,'MaxIter',40000);
%options=optimset(options,'TolX',1e-8);
%options=optimset(options,'TolFun',1e-8);

load 'H8692.mat'; clear H8692 dim_org dsize lambda;

dataSize = length(X(:,3))

F = X( :, 3);
N = X( :, 4);
R = X( :, 5); clear X;

ctmp=...
length(0.0:0.2:1.0)*...
length(0.0:0.5:2.5)*...
length(0.0:1.0:14.0)*...
length(0.0:0.1:1.0)*...
length(0.1:5.0:45.1);

T=sparse(ctmp,7);
icount=1;
for i=0.0:0.2:1.0
  for j=0.0:0.5:2.5
    for k=0.0:1.0:14.0
      for l=0.0:0.1:1.0
        for m=0.1:5.0:45.1
          tmp=F-exp( -i*(( R+m ).^-l).*N.^j  -k );
          T(icount,:)=[icount,(tmp'*tmp),i,j,k,l,m];
          icount=icount+1;
        end
      end
    end
  end
end; 
clear tmp i j k l m;

[C,I]=min(T(:,2))

beta0=[
    T(I,3);
    T(I,4);
    T(I,5);
    T(I,6);
    T(I,7)
]
clear T;

[beta, fval, exitflag, output] = fminunc('funCoef', beta0, options)

format long;
sse
dataSize
mse
aic=dataSize*log(mse)+2*(length(beta)+1)


parm = zeros(1,10);
parm = [beta(1), beta(2), beta(3), beta(4), beta(5), ...
         aic, sse, dataSize, fval, exitflag];
%fval
%output.funcCount

save 'plainEstCoefGrid.mat' parm;
elapseTime = etime(clock, t)
diary off
