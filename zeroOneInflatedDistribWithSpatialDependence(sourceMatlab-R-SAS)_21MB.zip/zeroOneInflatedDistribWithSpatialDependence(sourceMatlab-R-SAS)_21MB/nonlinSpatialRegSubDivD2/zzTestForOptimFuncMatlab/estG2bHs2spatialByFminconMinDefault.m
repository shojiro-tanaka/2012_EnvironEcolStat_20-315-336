clear; 
t = clock; 
global logitF logN R dataSize W sse mse; 
 
diary off 
disp('*** erase former log-file. ok? (hit any-key) ***') 
disp('(this matlab program list will be output to log)') 
pause 
 
!erase estG2bHs2spatial-fminconMinDefault.log; 
%!rm   estG2bHs2spatial-fminconMinDefault.log; 
diary('estG2bHs2spatial-fminconMinDefault.log'); 
!type  estG2bHs2spatialByFminconMinDefault.m; 
%!cat  estG2bHs2spatialByFminconMinDefault.m; 
disp('      ') 
disp('      ') 
disp('%%% applied FUNCTION %%%') 
disp('      ') 
!type funG2bHs2sp.m; 
%!cat funG2bHs2sp.m; 
disp('      ') 
disp('      ') 
disp('*** actual execution begins, ok? (hit any-key) ***') 
pause 
disp('      ') 
 
load 'H4logit.mat'; whos 
 
minusD = 0.995*(1/min(lambda)); 
plusD  = 0.995*(1/max(lambda)); 
F = X( :, 3); 
N = X( :, 4); 
R = X( :, 5); 
logitF = log( F ./ (1-F) ); 
logN   = log( N + 1 ); 
dataSize = dsize 
clear dsize dim_org N; 
 
Iterphi = 100; 
% IterPhi should be an even number to make balance between positive and negative iteration. 
count   = 0; 
 
beta0 = [ ... 
  -0.17401081265006; 
   4.45267134281981; 
  57.62447977375578; 
  52.40823091111448; 
   0.05102033981807; 
  12.95150685807391; 
   1.12519712515799 ... 
] 

A   = [];
b   = [];
Aeq = [];
beq = [];

lb = [ ...
 -8.01;
  0.01;
  0.01;
  0.01;
  0.01;
  0.01;
  0.01 ...
]

ub = [ ...
  8.01;
 10.01;
100.01;
100.01;
  1.01;
 20.01;
  5.01 ...
]

resv    = zeros(Iterphi,6+length(beta0)); 

%options = optimset('LargeScale','on','Display','iter'); 
%options = optimset(options,'MaxFunEvals',4000); 
%options = optimset(options,'MaxIter',500); 
%options = optimset(options,'TolX',1e-8); 
%options = optimset(options,'TolFun',1e-8); 
 
for phi = 0:(plusD-minusD)/(Iterphi-1):plusD 
   disp('      '); 
   disp('*** new iteration ***'); 
   phi 
   count = count + 1 
   W = speye(dataSize) - phi*H_mat; 
   fcount = 0; 
   [beta, Resnorm,FVAL,EXITFLAG,OUTPUT] = fmincon(@funG2bHs2sp, beta0, [],[],[],[],lb,ub)
%  [beta, Resnorm,FVAL,EXITFLAG,OUTPUT] = fmincon(@funG2bHs2sp, beta0)
   ldet   = - sum(log(1 - phi*lambda)); 
   aic    = dataSize*log(FVAL) + ldet + 2*sum(log(F.*(1-F))) + 2*(length(beta) + 2); 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, aic, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
ncount		= 0; 
 
for phi=0:-(plusD-minusD)/(Iterphi-1):minusD 
   disp('      '); 
   disp('*** new iteration ***'); 
   phi 
   count  = count+1 
   ncount = ncount - 1 
   W = speye(dataSize) - phi*H_mat; 
   fcount = 0; 
   [beta, Resnorm,FVAL,EXITFLAG,OUTPUT] = fmincon(@funG2bHs2sp, beta0, [],[],[],[],lb,ub)
   ldet   = - sum(log(1 - phi*lambda)); 
   aic    = dataSize*log(FVAL) + ldet + 2*sum(log(F.*(1-F))) + 2*(length(beta) + 2); 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, aic, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
resv = sortrows(resv, 2); 
 
format long; 
[minAIC, I] = min(resv(:,6)); 
minAIC 
beta=resv(I,7:13) 
phi=resv(I,2) 
 
%save 'parmG2bHs2spatial.mat' resv; 
elapseTime = etime(clock, t) 
diary off
