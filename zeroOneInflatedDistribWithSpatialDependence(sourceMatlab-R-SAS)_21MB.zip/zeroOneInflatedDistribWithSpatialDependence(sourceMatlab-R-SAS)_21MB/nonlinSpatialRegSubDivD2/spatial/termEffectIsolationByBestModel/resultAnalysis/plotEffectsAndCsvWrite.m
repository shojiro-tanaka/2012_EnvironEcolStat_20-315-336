diary off; clear;
format long; format compact

load 'termEffects.mat';
whos

varJoinAll = [logN, Yn, R, Yr];
length(varJoinAll)

figure, plot(R, Yr, 'g+')
title('R vs logitF substracting effects of N and neighbors')
figure, plot(logN, Yn, 'r*')
title('N vs logitF substracting effects of R and neighbors')

csvwrite('varJoinAll.csv', varJoinAll)

%%%  ( log(N+1) > 0 ) %%%
L = logN > 0.0;

varJoinPositiveN = varJoinAll(L,:);
length(varJoinPositiveN)

figure, plot(varJoinPositiveN(:,3), varJoinPositiveN(:,4),'g+')
title('R vs logitF substracting effects of N and neighbors for positive N')

figure, plot(varJoinPositiveN(:,1),varJoinPositiveN(:,2),'r*')
title('N vs logitF substracting effects of R and neighbors for positive N')

csvwrite('varJoinPositiveN.csv',varJoinPositiveN)
