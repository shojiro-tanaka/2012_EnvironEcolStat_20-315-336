 Times Roman font

The default font in LaTeX is Computer Modern Roman, which is perfectly acceptable for the SPIE Proceedings. If you prefer to create a manuscript in in Times Roman font, insert the command
\usepackage[]{times}
right after the \documentclass command. This package affects only the fonts used in the document text; the mathematical symbols remain in Computer Modern. It is, therefore, advisable to use the "-P pdf" option in DVIPS (mentioned below) to include the Type 1 fonts for the CMR mathematical symbols, and the G0 option (G and zero) as explained below. The DVIPS command looks like:
dvips filename.dvi -P pdf -G0
 Times Roman font

The default font in LaTeX is Computer Modern Roman, which is perfectly acceptable for the SPIE Proceedings. If you prefer to create a manuscript in in Times Roman font, insert the command
\usepackage[]{times}
right after the \documentclass command. This package affects only the fonts used in the document text; the mathematical symbols remain in Computer Modern. It is, therefore, advisable to use the "-P pdf" option in DVIPS (mentioned below) to include the Type 1 fonts for the CMR mathematical symbols, and the G0 option (G and zero) as explained below. The DVIPS command looks like:
dvips filename.dvi -P pdf -G0
============================================================
 DVIPS - converting DVI files to PostScript files

When latex is run, it produces a file with the extension DVI (for Device Independent), which completely encodes the formatted document, with the exception of the image files. A separate application is needed to view or print the document, or to convert the DVI file to a standard document format. The LaTeX application most often used for this purpose is DVIPS, which converts a DVI file to a PostScript (PS) file.

The utility DVIPS has numerous options to control various aspects of the PS file that it creates. The defaults depend on how LaTeX is installed on your system. To make sure that these options are set appropriately for your intended use, it is wise to explicitly specify them.

To summarize the following sections, it is a good idea to use the DVIPS options "-t letter -P pdf" for letter paper, and "-t a4 -P pdf", for A4 paper. In addition, if you use the times package, append the option list with -G0 (G zero).

If you execute DVIPS through a command line, the above options are included at the end of the command. In applications designed for window-based systems, e.g., Windows and the Mac OS, the DVI viewer may be based on DVIPS. In such applications, the DVIPS options can usually be specified. Check with your system administrator or read the manuals for your installation.

Paper size and margins

It is advisable to use the same paper-size option in DVIPS as specified in the \documentclass command in the LaTeX source file. The DVIPS option "-t" specifies paper size. For (USA) letter paper (8.5 in. X 11 in.), use the option "-t letter"; for A4 paper, use "-t a4".

With the paper size correctly specified, the margins of your LaTeX document should correctly follow the SPIE specifications.

If you need to adjust the position of the text field on the page, change the values of the LaTeX variables \voffset and \hoffset to move the text vertically or horizontally, respectively. For example, to lower the text 9 mm, include the command \addtolength{\voffset}{9mm} immediately after the \documentclass command at the beginning of the LaTeX source file.

Markus Knauer reported that the following prescription for A4 paper worked better for him: replace the lines in spie.cls, which set the margins for A4 paper, with the following:
\DeclareOption{a4paper}{%
\AtEndOfClass{%
\oddsidemargin -0.56cm % for side margins of 2cm
\evensidemargin -0.56cm % for side margins of 2cm
\topmargin -0.1cm
\typeout{a4paper used}
}
}
The same results can be achieved by placing the following commands at the beginning of article.tex:
\addtolength{\hoffset}{0.5mm}
\addtolength{\voffset}{-1mm}
Back to top

Type 1 PostScript Fonts

The PostScript files that are produced by DVIPS often looked awful when converted to PDF and viewed on a computer monitor with Acrobat Reader. The reason is that the PostScript output file typically contains Computer Modern Roman fonts that are bit-mapped, instead of "scalable" Type 1 PostScript fonts. The printer output is of high quality, but Acrobat doesn't handle them very well for viewing on a monitor. As an aside, this problem is diminishing with recent versions of Acrobat Reader.

There is a simple way to incorporate Type 1 PostScript fonts in PDF files produced from LaTeX output. The solution, suggested by Martin Edelmann, involves using the appropriate option in DVIPS. The suitable option is "-P pdf".

This option refers to the printer configuration file. For MS Windows, the file that specifies the default properties of the PostScript code produced by DVIPS is named config.ps. If the "P" or "j" options are set there, this option may not need to be set when running DVIPS. It seems that this default is becoming more prevalent.

If the above simple method doesn't work on your system, you can look at (http://www.math.hawaii.edu/~ralph/MathOnWeb/TeXPDF.html) for detailed advice on how to incorporate Type 1 PostScript fonts into the PostScript or PDF files generated from LaTeX DVI files.

Times package

With the times package, it is advisable to use the "-P pdf" option in DVIPS (mentioned above) to include the Type 1 fonts for the mathematical symbols, which are still in Computer Modern Roman font. However, using the times package with the "-P pdf" option in DVIPS causes a peculiar bug. For example, the pair of letters "fi" may appear as a British pound symbol. The reason for this behavior is that the G option is set in config.pdf (pdf.cfg). You can avoid the problem by commenting out that option in the config file or you can override it in the DVIPS command using the G0 option (G and zero). The DVIPS command looks like:
dvips filename.dvi -P pdf -G0
Thanks to Martin Edelmann for this solution.
Back to top

Reducing the size of large PS files

If the PS file that you get from DVIPS is large (>20 MB), it is probably because the EPS image files you are using for figures are large. DVIPS essentially copies the EPS image files into its output PS file. To reduce the size of the PS file, the best approach is to reduce the sizes of the image files.

PostScript files consist of instructions for building each page. The PS markup language specifies text in terms of scalable fonts and the position of each text string, and vector graphics commands to describe graphical features. The advantage of this way of describing a page is that it can be scaled to any size and the text and graphical elements still appear sharp. Some applications will directly produce this type of PS file, for example DVIPS. PS files are in ASCII text, so you can open them with a text editor and examine the PS instructions. An Encapsulated Postscript (EPS) file is a PS file that describes a single page, usually consisting of an image or a graph. EPS files differ from PS files in that they have a BoundingBox command
%%BoundingBox: 0 0 1200 900
near the beginning, which specifies the size of the image area. This command specifies the position and size of the image in PS units (72/inch) or in pixels, for a rasterized image, described below.

Some graphical applications produce EPS files in which the vector commands used to draw the graph are converted to similar PS commands. The size of this type of EPS file will depend on how many drawing commands are required to make the graph. If millions of points (or vectors) are drawn, the EPS file can become rather large. You can tell whether an EPS file is of this type by opening it with a text editor; the draw commands are easy to recognize.

An EPS file may contain a rasterized (or pixelated) image, which is defined in the EPS file as having a specific size, e.g., 1200 by 900 (pixels). This type of EPS image is created in the process of converting a rasterized image, such as GIF, PNG, or JPEG, to EPS. The list of pixel values can be uncompressed or compressed. The former can produce a rather large file. For example, an uncompressed 1200 by 900 pixel color image will be at least 3 MB in size. The compressed type of EPS image often employs JPEG compression, and is usually much smaller. The image file mcr3b.eps, provided above for the sample manuscript, is an example of this type of EPS file.

If you are using uncompressed rasterized EPS image files, the obvious way to make them much smaller is to convert them to compressed files using an application such as PhotoShop, IDL, or MatLab. If a large EPS file uses vector coding, the solution is to convert it to a rasterized image file (for example, GIF, PNG, or JPEG), and then convert that to a compressed rasterized EPS file.

The resolution of the rasterized images employed in the previous paragraph should be high enough to maintain the quality of the published image or graph. A pixel density of 300 to 400 dpi (dots per inch = pixels per inch) on the printed page may be good enough. Attention should be given to the selection of the JPEG resolution option. The option of "maximum quality" is often not needed - either "high" or "medium" quality usually provides satisfactory print quality and saves disk space.
Back to top
DVI to PDF

Several utilities provide the capability of converting a DVI file directly into a PDF file. While SPIE specifies that electronically submitted manuscripts must be in PS format, authors may find PDF files advantageous for other purposes, for example, to post a LaTeX document on a web site.

The utility dvipdfm directly produces a PDF file from the DVI file. This utility is included in many LaTeX distributions. The command is:
dvipdfm filename.dvi
Appealing aspects of this utility are that Acrobat Distiller is not needed, and Type 1 PostScript fonts are automatically included in the resulting PDF file. Furthermore, dvipdfm allows one to directly incorporate images in JPEG, PNG, and PDF formats, and not just EPS. It is possible to include hyperlinks to items within the document, such as references, equations, etc., or to URLs on the web by using the LaTeX package hyperref.sty. This solution was suggested by Adrian Sequeira. [Note the potential conflict between hyperref.sty and cite.sty, which is employed in spie.cls.]

Other utilities for creating acceptable PDF files are available, for example, pdftex, which also comes with MiKTeX or is directly available from the CTAN web pages (http://www.ctan.org/).
