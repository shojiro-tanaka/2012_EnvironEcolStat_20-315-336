

# �L���̑S�f�[�^�𗘗p�C�W�{�� = 6824
res1  = read.csv('varJoinAll.csv')
res1R = cbind(res1[,3], res1[,4])
res1N = cbind(res1[,1], res1[,2])
dim(res1)


# �S�f�[�^�ɑ΂���(R, logitF ����N ���̉e�����������l) �̃v���b�g
windows()
plot(res1R, main = "Lowess for R vs R effect")
lines(lowess(res1R, f = 0.1, iter=5), col = 2)
lines(lowess(res1R, f = 0.5, iter=5), col = 3)
lines(lowess(res1R, f = 1.0, iter=5), col = 4)
lines(lowess(res1R, f = 1.5, iter=5), col = 5)
lines(lowess(res1R, f = 2.0, iter=5), col = 6)

bmp(file="Lowess_R_Reffect_n_6824_withTitle.bmp")
plot(res1R, main = "Lowess for R vs R effect")
lines(lowess(res1R, f = 0.1, iter=5), col = 2)
lines(lowess(res1R, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_R_Reffect_n_6824_withTitle.eps")
plot(res1R, main = "Lowess for R vs R effect")
lines(lowess(res1R, f = 0.1, iter=5), col = 2)
lines(lowess(res1R, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_R_Reffect_n_6824.eps") 
plot(res1R, xlab='', ylab='')
lines(lowess(res1R, f = 0.1, iter=5), col = 2)
lines(lowess(res1R, f = 1.0, iter=5), col = 4)
dev.off()

# �S�f�[�^�ɑ΂���(log(N+1), logitF ����R ���̉e�����������l) �̃v���b�g
windows()
plot(res1N, main = "Lowess for log(N+1) vs N effect")
lines(lowess(res1N, f = 0.1, iter=5), col = 2)
lines(lowess(res1N, f = 0.5, iter=5), col = 3)
lines(lowess(res1N, f = 1.0, iter=5), col = 4)
lines(lowess(res1N, f = 1.5, iter=5), col = 5)
lines(lowess(res1N, f = 2.0, iter=5), col = 6)

bmp(file="Lowess_log(N+1)_Neffect_n_6824_withTitle.bmp")
plot(res1N, main = "Lowess for R vs R effect")
lines(lowess(res1N, f = 0.1, iter=5), col = 2)
lines(lowess(res1N, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_log(N+1)_Neffect_n_6824_withTitle.eps")
plot(res1N, main = "Lowess for R vs R effect")
lines(lowess(res1N, f = 0.1, iter=5), col = 2)
lines(lowess(res1N, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_log(N+1)_Neffect_n_6824.eps") 
plot(res1N, xlab='', ylab='')
lines(lowess(res1N, f = 0.1, iter=5), col = 2)
lines(lowess(res1N, f = 1.0, iter=5), col = 4)
dev.off()



%%%%%  �L���� N > 0 �̃f�[�^�Ɍ���, �W�{�� = 3219   
res2  = read.csv('varJoinPositiveN.csv')
res2R = cbind(res2[,3], res2[,4])
res2N = cbind(res2[,1], res2[,2])
dim(res2)

# N > 0 �̃f�[�^�ɑ΂���(R, logitF ����N ���̉e�����������l) �̃v���b�g
windows()
plot(res2R, main = "Lowess for R vs R effect")
lines(lowess(res2R, f = 0.1, iter=5), col = 2)
lines(lowess(res2R, f = 0.5, iter=5), col = 3)
lines(lowess(res2R, f = 1.0, iter=5), col = 4)
lines(lowess(res2R, f = 1.5, iter=5), col = 5)
lines(lowess(res2R, f = 2.0, iter=5), col = 6)

bmp(file="Lowess_R_Reffect_n_3219_withTitle.bmp")
plot(res2R, main = "Lowess for R vs R effect")
lines(lowess(res2R, f = 0.1, iter=5), col = 2)
lines(lowess(res2R, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_R_Reffect_n_3219_withTitle.eps")
plot(res2R, main = "Lowess for R vs R effect")
lines(lowess(res2R, f = 0.1, iter=5), col = 2)
lines(lowess(res2R, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_R_Reffect_n_3219.eps") 
plot(res2R, xlab='', ylab='')
lines(lowess(res2R, f = 0.1, iter=5), col = 2)
lines(lowess(res2R, f = 1.0, iter=5), col = 4)
dev.off()


# N > 0 �̃f�[�^�ɑ΂���(log(N+1), logitF ����R ���̉e�����������l) �̃v���b�g
windows()
plot(res2N, main = "Lowess for log(N+1) vs N effect")
lines(lowess(res2N, f = 0.1, iter=5), col = 2)
lines(lowess(res2N, f = 0.5, iter=5), col = 3)
lines(lowess(res2N, f = 1.0, iter=5), col = 4)
lines(lowess(res2N, f = 1.5, iter=5), col = 5)
lines(lowess(res2N, f = 2.0, iter=5), col = 6)

bmp(file="Lowess_log(N+1)_Neffect_n_3219_withTitle.bmp")
plot(res2N, main = "Lowess for R vs R effect")
lines(lowess(res2N, f = 0.1, iter=5), col = 2)
lines(lowess(res2N, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_log(N+1)_Neffect_n_3219_withTitle.eps")
plot(res2N, main = "Lowess for R vs R effect")
lines(lowess(res2N, f = 0.1, iter=5), col = 2)
lines(lowess(res2N, f = 1.0, iter=5), col = 4)
dev.off()

pdf(file="Lowess_log(N+1)_Neffect_n_3219.eps") 
plot(res2N, xlab='', ylab='')
lines(lowess(res2N, f = 0.1, iter=5), col = 2)
lines(lowess(res2N, f = 1.0, iter=5), col = 4)
dev.off()

