format long; 

load 'parmG2bHs2spatial.mat';
[minLogLikelihood, I] = min(resv(:,6)); 
minLogLikelihood
beta  = resv(I,7:15) 
phi   = resv(I,2)
FVAL  = resv(I,4)
mse   = resv(I,5)