diary off; clear;

load '../../dataPreparation/zzSpatialDataWithF0F1NeighborNum.mat'; clear dSizeAll;
load '../../dataPreparation/H4logit.mat'; clear X dim_org dsize lambda;
load 'parmG2bHs2spatial.mat';

F    = XX(:,1); 
N    = XX(:,2); 
R    = XX(:,3); 
xF0  = XX(:,4);
xF1  = XX(:,5);

logitF = log( F ./ (1-F) ); 
logN   = log( N + 1 ); 
dataSize = dSize4logit
clear dSize4logit F N XX; 

[minLogLikelihood, I] = min(resv(:,6)); 
minLogLikelihood
beta  = resv(I,7:15) 
phi   = resv(I,2)
FVAL  = resv(I,4)
mse   = resv(I,5)

whos

termNbr = zeros(dataSize,1); 
termNbr = -beta(2)*xF0 + beta(3)*xF1;

termLogN = zeros(dataSize,1); 
termLogN = ... 
   +beta(4) * ... 
   - ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ... 
      -1.0./(1.0+exp(beta(5))) ); 
 
termR = zeros(dataSize,1); 
clear k; 
for k = 1:dataSize 
   if R(k)  > beta(8) 
      termR(k) = beta(9)*log( R(k)/beta(8) ) ; 
   end 
end 
clear k; 


%%% H_mat:neighbor matrix %%%
Et = logitF - beta(1) -termNbr -termLogN -termR;
sumEt = H_mat*Et;


Yr = zeros(dataSize,1);
Yr = logitF -beta(1) -termNbr -termLogN -phi*sumEt;
Yn = zeros(dataSize,1);
Yn = logitF -beta(1) -termNbr -termR    -phi*sumEt;

save 'termEffects.mat' logitF logN R Yr Yn sumEt;
