diary off; clear;
format long; 

load 'termEffects.mat';
whos

varJoin = [logN, Yn, R, Yr];
length(varJoin)

%%%  ( log(N+1) > 0 ) %%%
L = logN > 0.0;

varJoin = varJoin(L,:);
length(varJoin)

figure,plot(varJoin(:,3),varJoin(:,4),'g+')
figure,plot(varJoin(:,1),varJoin(:,2),'r*')

csvwrite('varJoin.csv',varJoin)

