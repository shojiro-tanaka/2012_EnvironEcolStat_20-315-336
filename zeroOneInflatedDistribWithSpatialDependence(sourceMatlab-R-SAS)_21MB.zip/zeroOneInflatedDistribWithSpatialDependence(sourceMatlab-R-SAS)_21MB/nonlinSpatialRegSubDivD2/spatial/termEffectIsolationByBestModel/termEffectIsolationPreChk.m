diary off; clear;

load '../../dataPreparation/H4logit.mat'; 
load '../../dataPreparation/zzSpatialDataWithF0F1NeighborNum.mat';
load 'parmG2bHs2spatial.mat';

F    = X (:,3); 
N    = X (:,4); 
R    = X (:,5); 
Fchk = XX(:,1); 
Nchk = XX(:,2); 
Rchk = XX(:,3); 
xF0  = XX(:,4);
xF1  = XX(:,5);

logitF = log( F ./ (1-F) ); 
logN   = log( N + 1 ); 
dataSize = dsize
dSize4logit
clear dsize dSize4logit dim_org N X XX lambda dSizeAll; 

for i = 1:dataSize
   if Fchk(i,1) ~= F(i,1) or Nchk(i,1) ~= N(i,1) or Rchk(i,1) ~= R(i,1)
      disp('wrong data!')
   end
end

[minLogLikelihood, I] = min(resv(:,6)); 
minLogLikelihood
beta  = resv(I,7:15) 
phi   = resv(I,2)
FVAL  = resv(I,4)
mse   = resv(I,5)

whos

termN = zeros(dataSize,1); 
termN = ... 
   -beta(2)*xF0 + beta(3)*xF1 ...
   +beta(4) * ... 
   - ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ... 
      -1.0./(1.0+exp(beta(5))) ); 
 
termR = zeros(dataSize,1); 
clear k; 
for k = 1:dataSize 
   if R(k)  > beta(8) 
      termR(k) = beta(9)*log( R(k)/beta(8) ) ; 
   end 
end 
clear k; 
 

%%% WRONG! below%%%
C = logitF - (beta(1) + termN + termR); 
mse2 = (C'*C)/dataSize
mse 

Yr = zeros(dataSize,1);
Yr = logitF -beta(1) -termN -phi*mse;
Yn = zeros(dataSize,1);
Yn = logitF -beta(1) -termR -phi*mse;

save 'termEffectsPre.mat' logitF logN R Yr Yn;
