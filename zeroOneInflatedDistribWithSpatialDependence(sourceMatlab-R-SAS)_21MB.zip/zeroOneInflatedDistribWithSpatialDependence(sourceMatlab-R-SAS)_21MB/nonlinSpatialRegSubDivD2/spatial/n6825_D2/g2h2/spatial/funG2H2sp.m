function mse = funG2H2sp(beta) 
global logitF logN R dataSize xF0 xF1 W sse mse; 
 
B = zeros(dataSize,1); 
B = beta(1) + ... 
   +beta(2)*xF0 + beta(3)*xF1 ...
   -beta(4) * ... 
    ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ... 
   -1.0./(1.0+exp(beta(5))) ); 
 
clear k; 
for k = 1:dataSize 
   if R(k) > beta(8) 
      B(k) = B(k) + beta(9)*log( R(k)/beta(8) ) ; 
   end 
end 
clear k; 
 
C = logitF - B; 
 
sse = C'*W*C; 
 
if sse < 0 
   disp('sse negative!'); 
end 
 
mse = sse/dataSize; 
 
%%% eof %%% 
