clear; 
t = clock; 
global logitF logN R dataSize xF0 xF1 W sse mse; 
 
diary off 
disp('*** erase former log-file. ok? (hit any-key) ***') 
disp('(this matlab program list will be output to log)') 
pause 
 
!erase estG2H2spatial.log; 
%!rm   estG2H2spatial.log; 
diary('estG2H2spatial.log'); 
!type  estG2H2spatial.m; 
%!cat  estG2H2spatial.m; 
disp('      ') 
disp('      ') 
disp('%%% applied FUNCTION %%%') 
disp('      ') 
!type funG2H2sp.m; 
%!cat funG2H2sp.m; 
disp('      ') 
disp('      ') 
disp('*** actual execution begins, ok? (hit any-key) ***') 
pause 
disp('      ') 
 
load '../../../../dataPreparation/H4logit.mat'; 
load '../../../../dataPreparation/zzSpatialDataWithF0F1NeighborNum.mat'; whos 
 
minusD = 0.995*(1/min(lambda)); 
plusD  = 0.995*(1/max(lambda)); 
F   = XX(:,1); 
N   = XX(:,2); 
R   = XX(:,3); 
xF0 = XX(:,4);
xF1 = XX(:,5);

logitF = log( F ./ (1.0 - F) ); 
pwN    = log( N + 1.0 ); 
pwR    = R;

dataSize = dSize4logit
clear dSizeAll dSize4logit N R XX; 

minusD = 0.995*(1/min(lambda)); 
plusD  = 0.995*(1/max(lambda)); 
F = X( :, 3); 
N = X( :, 4); 
R = X( :, 5); 
logitF = log( F ./ (1-F) ); 
logN   = log( N + 1 ); 
dataSize = dsize 
clear dsize dim_org N; 
 
Iterphi = 100; 
% IterPhi should be an even number to make balance between positive and negative iteration. 
count   = 0; 
 
beta0 = [ ... 
  -3.3016 ;
  -0.3680 ;
   0.1459 ;
   1.0000 ;
  83.6440 ;
  57.9934 ;
   0.1392 ;
   4.0778 ;
   1.1477 ...
] 
resv    = zeros(Iterphi,7+length(beta0)); 
 
%options=optimset('Display','iter'); 
options=optimset('LargeScale','off','Display','iter'); 
options=optimset(options,'MaxFunEvals',1000); 
options=optimset(options,'MaxIter',200); 
%options=optimset(options,'TolX',1e-8); 
%options=optimset(options,'TolFun',1e-8); 
 
for phi = 0:(plusD-minusD)/(Iterphi-1):plusD 
   disp('      '); 
   disp('*** new iteration ***'); 
   phi 
   count = count + 1 
   W = speye(dataSize) - phi*H_mat; 
   fcount = 0; 
   [beta, fval, exitflag, output] = fminunc('funG2H2sp', beta0, options) 
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + 2*sum(log(F.*(1-F))); 
   resv( count, : ) = [count, phi, ldet, mse, logLikelihood, fval, exitflag, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
ncount		= 0; 
 
for phi=0:-(plusD-minusD)/(Iterphi-1):minusD 
   disp('      '); 
   disp('*** new iteration ***'); 
   phi 
   count  = count+1 
   ncount = ncount - 1 
   W = speye(dataSize) - phi*H_mat; 
   fcount = 0; 
   [beta, fval, exitflag, output] = fminunc('funG2H2sp', beta0, options) 
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + 2*sum(log(F.*(1-F))); 
   resv( count, : ) = [count, phi, ldet, mse, logLikelihood, fval, exitflag, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
resv = sortrows(resv, 2); 
 
format long; 
[minLogLikelihood, I] = min(resv(:,5)); 
minLogLikelihood
beta=resv(I,8:16) 
phi=resv(I,2) 
 
save 'parmG2H2spatial.mat' resv; 
elapseTime = etime(clock, t) 
diary off 