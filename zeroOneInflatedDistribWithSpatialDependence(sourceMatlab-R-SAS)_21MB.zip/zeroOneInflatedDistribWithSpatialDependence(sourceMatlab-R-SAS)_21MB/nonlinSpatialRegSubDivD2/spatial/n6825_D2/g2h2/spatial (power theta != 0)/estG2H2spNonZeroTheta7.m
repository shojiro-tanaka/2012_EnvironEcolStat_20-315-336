clear; diary off  
global pwFracF logN R dataSize xF0 xF1 W mse;  
 
t = clock; 
disp('*** erase former log-file. ok? (hit any-key) ***')  
disp('(this matlab program list will be output to log)')  
pause  
  
!erase estG2H2spNonZeroTheta7.log;  
diary('estG2H2spNonZeroTheta7.log');  
!type  estG2H2spNonZeroTheta7.m;  
disp('      ')  
disp('      ')  
disp('%%% applied FUNCTION %%%')  
disp('      ')  
!type funG2H2sp2NonZeroTheta.m;  
disp('      ')  
 
load '../../../../dataPreparation/zzSpatialDataWithF0F1NeighborNum.mat'; clear dSizeAll; 
load '../../../../dataPreparation/H4logit.mat'; clear X dim_org dsize; 
 
minusD = 0.995*(1/min(lambda));  
plusD  = 0.995*(1/max(lambda));  
F    = XX(:,1);  
N    = XX(:,2);  
R    = XX(:,3);  
xF0  = XX(:,4); 
xF1  = XX(:,5); 
logN = log( N + 1.0 );  
 
fracF  = F ./ (1.0 - F);  
 
dataSize = dSize4logit 
clear dSizeAll dSize4logit XX N; 
 
options = optimset('LargeScale','off','Display','off');  
options = optimset(options,'MaxFunEvals',4000);  
options = optimset(options,'MaxIter',500);  
options = optimset(options,'TolX',1e-10);  
options = optimset(options,'TolFun',1e-12);  
 
FtoPower = [-0.02105:0.00005:-0.02095]';

lF = FtoPower ~= 0.0; 
 
FtoPower = FtoPower(lF); 
 
disp('      ')  
totalTransformations = length(FtoPower); 
disp('total transformation number = ') 
disp(totalTransformations) 
disp('      ')  
disp('*** actual execution begins, ok? (hit any-key) ***')  
pause  
 
arrayMinLogLikelihood = zeros(length(FtoPower),1); 
 
disp('common beta0')  
beta0 = [ ... 
  -0.16846813198106;
  -0.25488722834439;
   0.25132367229126;
   5.14049283112935;
  57.89906506752597;
  52.94513265810710;
   0.04471774726707;
   5.01;
   1.05767538286586 ...
] 

disp('      ')  
%%% loop begins %%% 
 
for f = 1:length(FtoPower) 
pwFracF    = ( (fracF    ).^FtoPower(f) - 1.0 ) / FtoPower(f);  
 
transformAdjustTerm = 2*sum( log(F.*(1-F)) - FtoPower(f)*log(fracF) ); 
 
Iterphi = 100;  
% IterPhi should be an even number to make balance between positive and negative iteration.  
count   = 0;  
 
resv    = zeros(Iterphi,6+length(beta0));  
 
disp('      ')  
disp('%%% power transformation %%%')  
disp('FtoPower=') 
disp(FtoPower(f)) 
 
for phi = 0:(plusD-minusD)/(Iterphi-1):plusD  
   disp('      ');  
   disp('*** new iteration ***');  
   phi  
   count = count + 1; 
   W = speye(dataSize) - phi*H_mat;  
   fcount = 0;  
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funG2H2sp2NonZeroTheta, beta0, options); 
   ldet   = - sum(log(1 - phi*lambda));  
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta'];  
   if mse < 0  
      disp('mse negative!');  
      %   return  
   end  
end  
  
ncount		= 0;  
  
for phi=0:-(plusD-minusD)/(Iterphi-1):minusD  
   disp('      ');  
   disp('*** new iteration ***');  
   phi  
   count  = count + 1;  
   ncount = ncount - 1;  
   W = speye(dataSize) - phi*H_mat;  
   fcount = 0;  
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funG2H2sp2NonZeroTheta, beta0, options); 
   ldet   = - sum(log(1 - phi*lambda));  
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta'];  
   if mse < 0  
      disp('mse negative!');  
      %   return  
   end  
end  
 
resv = sortrows(resv, 2);  
  
format long;  
[minLogLikelihoodPre, I] = min(resv(:,6));  
minLogLikelihoodPre 
beta=resv(I,7:15)' 
phi=resv(I,2)  
mse=resv(I,5) 
 
arrayMinLogLikelihood(f) = minLogLikelihoodPre; 
 
end 
 
[minLogLikelihood, J] = min(arrayMinLogLikelihood); 
 
minLogLikelihood 
fToPwr = FtoPower(J) 
 
save 'minLogLikelihood7.mat' arrayMinLogLikelihood fToPwr FtoPower; 
 
elapseTimeMin = etime(clock, t)/60.0 
 
diary off
