load 'minLogLikelihoodQuadLoops4.mat'; 

minLogLikelihood = min(min(min(arrayMinLogLikelihood)))
maxLogLikelihood = max(max(max(arrayMinLogLikelihood)))

relativeValueArray = (arrayMinLogLikelihood-minLogLikelihood)/(maxLogLikelihood-minLogLikelihood);

clear i;
emp=zeros(length(FtoPower),1);
for i=1:length(FtoPower)
  emp(i) = isempty(find(relativeValueArray(:,:,i)==0));
end
clear i L;

iF = find(emp == 0);

L = emp == 0;
relativeValueArray2 = relativeValueArray(:,:,L);
clear L;

colormap(hot(64))
image(512*relativeValueArray2)

diary off;
