clear; diary off 
global pwFracF pwN pwR dataSize xF0 xF1 W mse; 

t = clock;
disp('*** erase former log-file. ok? (hit any-key) ***') 
disp('(this matlab program list will be output to log)') 
pause 
 
!erase estNewSpatialQuadLoops1stTrial.log; 
%!rm   estNewSpatialQuadLoops1stTrial.log; 
diary('estNewSpatialQuadLoops1stTrial.log'); 
!type  estNewSpatialQuadLoops1stTrial.m; 
%!cat  estNewSpatialQuadLoops1stTrial.m; 
disp('      ') 
disp('      ') 
disp('%%% applied FUNCTION %%%') 
disp('      ') 
!type funNewSpatialForQuadLoops2.m; 
%!cat funNewSpatialForQuadLoops2.m; 
disp('      ') 

load '../../../dataPreparation/H3220.mat'; 
load '../../../dataPreparation/zzSpatialDataWithF0F1NeighborNumNonZeroN.mat'; whos 
 
minusD = 0.995*(1/min(lambda)); 
plusD  = 0.995*(1/max(lambda)); 
F   = XX(:,1); 
N   = XX(:,2); 
R   = XX(:,3); 
xF0 = XX(:,4);
xF1 = XX(:,5);

fracF  = F ./ (1.0 - F); 

dataSize = dSize4logitNonZeroN
clear dSizeAll dSize4logitNonZeroN XX;

options = optimset('LargeScale','off','Display','off'); 
options = optimset(options,'MaxFunEvals',4000); 
options = optimset(options,'MaxIter',500); 
options = optimset(options,'TolX',1e-10); 
options = optimset(options,'TolFun',1e-12); 
 
RtoPower = [-0.5,-0.25,0.001,0.25,0.5]';
NtoPower = [-0.10,-0.05,0.001,0.05,0.10]';
FtoPower = [-0.10,-0.05,0.001,0.05,0.10]';

lR = RtoPower ~= 0.0;
lN = NtoPower ~= 0.0;
lF = FtoPower ~= 0.0;

RtoPower = RtoPower(lR);
NtoPower = NtoPower(lN);
FtoPower = FtoPower(lF);

disp('      ') 
totalTransformations = length(NtoPower)*length(RtoPower)*length(FtoPower);
disp('total transformation number = ')
disp(totalTransformations)
disp('      ') 
disp('*** actual execution begins, ok? (hit any-key) ***') 
pause 

arrayMinLogLikelihood = zeros(length(RtoPower),length(NtoPower),length(FtoPower));

disp('common beta0') 
beta0 = [ ...
   2.50;
   0.30;
   0.15;
   0.55;
   0.01 ...
]

disp('      ') 
%%% triplet loop begins %%%

for r = 1:length(RtoPower)
pwR   = ( (R+1.0).^RtoPower(r) - 1.0 ) / RtoPower(r); 
for n = 1:length(NtoPower)
pwN   = ( (N+1.0).^NtoPower(n) - 1.0 ) / NtoPower(n); 
for f = 1:length(FtoPower)
pwFracF    = ( (fracF    ).^FtoPower(f) - 1.0 ) / FtoPower(f); 
%pwFracF   = ( (fracF+1.0).^FtoPower(f) - 1.0 ) / FtoPower(f); 

transformAdjustTerm = 2*sum( log(F.*(1-F)) - FtoPower(f)*log(fracF) );

Iterphi = 100; 
% IterPhi should be an even number to make balance between positive and negative iteration. 
count   = 0; 

resv    = zeros(Iterphi,6+length(beta0)); 

disp('      ') 
disp('%%% power transformation %%%') 
disp('RtoPower=')
disp(RtoPower(r))
disp('NtoPower=')
disp(NtoPower(n))
disp('FtoPower=')
disp(FtoPower(f))

for phi = 0:(plusD-minusD)/(Iterphi-1):plusD 
   %disp('      '); 
   %disp('*** new iteration ***'); 
   %phi 
   count = count + 1;
   W = speye(dataSize) - phi*H3220; 
   fcount = 0; 
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funNewSpatialForQuadLoops2, beta0, options);
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm;
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
ncount		= 0; 
 
for phi=0:-(plusD-minusD)/(Iterphi-1):minusD 
   %disp('      '); 
   %disp('*** new iteration ***'); 
   %phi 
   count  = count + 1; 
   ncount = ncount - 1; 
   W = speye(dataSize) - phi*H3220; 
   fcount = 0; 
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funNewSpatialForQuadLoops2, beta0, options);
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm; 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 

resv = sortrows(resv, 2); 
 
format long; 
[minLogLikelihoodPre, I] = min(resv(:,6)); 
minLogLikelihoodPre
beta=resv(I,7:11)'
phi=resv(I,2) 

arrayMinLogLikelihood(r,n,f) = minLogLikelihoodPre;

end
end
end

minLogLikelihood = min(min(min(arrayMinLogLikelihood)))
maxLogLikelihood = max(max(max(arrayMinLogLikelihood)))

relativeValueArray = (arrayMinLogLikelihood-minLogLikelihood)/(maxLogLikelihood-minLogLikelihood)

clear i;
emp=zeros(length(FtoPower),1);
for i=1:length(FtoPower)
  emp(i) = isempty(find(relativeValueArray(:,:,i)==0));
end
clear i L;

iF = find(emp == 0);

L = emp == 0;
relativeValueArray2 = relativeValueArray(:,:,L)
clear L;

[ir,in] = find( relativeValueArray2 == 0.0 )

rToPwr = RtoPower(ir)
nToPwr = NtoPower(in)
fToPwr = FtoPower(iF)

save 'minLogLikelihoodQuadLoops1stTrial.mat' arrayMinLogLikelihood rToPwr nToPwr fToPwr RtoPower NtoPower FtoPower;

elapseTimeMin = etime(clock, t)/60.0
totalTransformations

diary off
