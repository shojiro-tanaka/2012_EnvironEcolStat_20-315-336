see funNewSpatialForTriLoops2.m, the two signs were reversed!
