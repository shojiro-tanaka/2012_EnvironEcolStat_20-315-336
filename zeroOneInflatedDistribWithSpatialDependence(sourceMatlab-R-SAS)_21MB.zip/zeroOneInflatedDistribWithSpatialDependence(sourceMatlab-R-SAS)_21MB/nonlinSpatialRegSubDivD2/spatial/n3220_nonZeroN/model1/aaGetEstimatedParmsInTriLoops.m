clear; diary off 
global logitF pwN pwR dataSize xF0 xF1 W mse; 

load 'minLogLikelihoodTriLoops4.mat'; 
load '../../../dataPreparation/H3220.mat'; 
load '../../../dataPreparation/zzSpatialDataWithF0F1NeighborNumNonZeroN.mat';

diary('zzGetEstimatedParmsTriLoops3.log'); 
!type  aaGetEstimatedParmsInTriLoops.m; 
disp('      ') 
disp('      ') 
disp('%%% applied FUNCTION %%%') 
disp('      ') 
!type funNewSpatialForTriLoops2.m; 
disp('      ') 

minusD = 0.995*(1/min(lambda)); 
plusD  = 0.995*(1/max(lambda)); 
F   = XX(:,1); 
N   = XX(:,2); 
R   = XX(:,3); 
xF0 = XX(:,4);
xF1 = XX(:,5);

logitF  = log( F ./ (1.0 - F) ); 

dataSize = dSize4logitNonZeroN
clear dSizeAll dsize dim_org dSize4logitNonZeroN X XX; whos

options = optimset('LargeScale','off','Display','iter'); 
options = optimset(options,'MaxFunEvals',4000); 
options = optimset(options,'MaxIter',500); 
options = optimset(options,'TolX',1e-10); 
options = optimset(options,'TolFun',1e-12); 

disp('beta0') 
beta0 = [ ...
   2.50;
   0.30;
   0.15;
   0.55;
   0.01 ...
]

disp('      ') 
rToPwr
nToPwr
pwR   = ( (R+1.0).^rToPwr - 1.0 ) / rToPwr; 
pwN   = ( (N+1.0).^nToPwr- 1.0 ) / nToPwr; 
transformAdjustTerm = 2*sum( log(F.*(1-F)) );

Iterphi = 500; 
% IterPhi should be an even number to make balance between positive and negative iteration. 
count   = 0; 

resv    = zeros(Iterphi,6+length(beta0)); 

for phi = 0:(plusD-minusD)/(Iterphi-1):plusD 
   %disp('      '); 
   %disp('*** new iteration ***'); 
   %phi 
   count = count + 1;
   W = speye(dataSize) - phi*H3220; 
   fcount = 0; 
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funNewSpatialForTriLoops2, beta0, options);
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm;
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 
 
ncount		= 0; 
 
for phi=0:-(plusD-minusD)/(Iterphi-1):minusD 
   %disp('      '); 
   %disp('*** new iteration ***'); 
   %phi 
   count  = count + 1; 
   ncount = ncount - 1; 
   W = speye(dataSize) - phi*H3220; 
   fcount = 0; 
   [beta,FVAL,EXITFLAG,OUTPUT] = fminunc(@funNewSpatialForTriLoops2, beta0, options);
   ldet   = - sum(log(1 - phi*lambda)); 
   logLikelihood    = dataSize*log(mse) + ldet + transformAdjustTerm; 
   resv( count, : ) = [count, phi, ldet, FVAL, mse, logLikelihood, beta']; 
   if mse < 0 
      disp('mse negative!'); 
      %   return 
   end 
end 

resv = sortrows(resv, 2); 
 
format long; 
[minLogLikelihoodPre, I] = min(resv(:,6)); 
minLogLikelihoodPre
mse
phi=resv(I,2) 
beta=resv(I,7:11)
rToPwr
RtoPower
nToPwr
NtoPower

minLogLikelihood = min(min(arrayMinLogLikelihood))
maxLogLikelihood = max(max(arrayMinLogLikelihood))

relativeValueArray = (arrayMinLogLikelihood-minLogLikelihood)/(maxLogLikelihood-minLogLikelihood);

save 'parmBestInTriLoops4.mat' resv minLogLikelihoodPre mse phi beta;

colormap(hot(64))
image(512*relativeValueArray)

diary off;
