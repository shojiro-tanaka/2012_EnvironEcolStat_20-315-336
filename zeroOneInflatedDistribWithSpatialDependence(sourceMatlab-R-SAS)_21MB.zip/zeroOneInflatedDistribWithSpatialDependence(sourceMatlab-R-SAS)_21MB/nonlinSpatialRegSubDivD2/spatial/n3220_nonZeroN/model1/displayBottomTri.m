load 'minLogLikelihoodTriLoops5.mat'; 

minLogLikelihood = min(min(arrayMinLogLikelihood))
maxLogLikelihood = max(max(arrayMinLogLikelihood))

relativeValueArray = (arrayMinLogLikelihood-minLogLikelihood)/(maxLogLikelihood-minLogLikelihood);

colormap(hot(64))
image(512*relativeValueArray)

diary off;
