diary off; clear;

load zzAllDataWithCoordinateValues; 

tmpMinX=min(XX(:,1))
tmpMinY=min(XX(:,2))

XX(:,1)=XX(:,1)-tmpMinX+1;
XX(:,2)=XX(:,2)-tmpMinY+1;
clear tmpMinX tmpMinY;

maxX=max(XX(:,1))
minX=min(XX(:,1))
maxY=max(XX(:,2))
minY=min(XX(:,2))

[rowXX, colXX] = size(XX);
dataSize = rowXX

logN  = log(XX(:,4)+1);
R     = XX(:,5);
xF0   = XX(:,6);
xF1   = XX(:,7);
fracF = XX(:,3)./(1.0-XX(:,3)) ;
x     = XX(:,1);
y     = XX(:,2);

clear XX;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load bestParmsWithFinerPhi;
minLogLikelihood
clear FtoPower minLogLikelihood;

pwFracF   = ( (fracF    ).^fToPwr - 1.0 ) / fToPwr; 

B = zeros(dataSize,1);  
 
clear k;  
for k = 1:dataSize  
   if R(k) > beta(8)  
      B(k) = B(k) + beta(9)*log( R(k)/beta(8) ) ;  
   end  
end  
clear k;  
 
if logN == 0 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1; 
else 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1 ... 
   -beta(4) * ...  
    ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ...  
   -1.0./(1.0+exp(beta(5))) );  
end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e     = pwFracF - B;
conde = zeros(length(e), 1);

gridConde = zeros(maxY,maxX);
for i  = 1:maxX
 xx = x(i); 
 for j = 1:maxY
  yy = y(j);
  site = find( x == xx & y == yy);
  if length(site) == 1
   enbd = 0;
   ff = find( x == xx+1 & y == yy+1 );
   if length(ff) == 1, enbd = enbd + e(ff); end
   ff = find( x == xx-1 & y == yy+1 );
   if length(ff) == 1, enbd = enbd + e(ff); end
   ff = find( x == xx+1 & y == yy-1 );
   if length(ff) == 1, enbd = enbd + e(ff); end
   ff = find( x == xx-1 & y == yy-1 );
   if length(ff) == 1, enbd = enbd + e(ff); end
   conde(site) = e(site) -  phi* enbd;
  end
 end
end

mean(conde)
var( conde)
%figure,hist(conde, 30)

mean(e)
var (e)
%figure,hist(e, 30)

z  = [x, y, e, conde];
%l  = find(z(:,4)~=0);
%z2 = z(l,:);
%nonZeroNum = length(z2); % 135�̂�
