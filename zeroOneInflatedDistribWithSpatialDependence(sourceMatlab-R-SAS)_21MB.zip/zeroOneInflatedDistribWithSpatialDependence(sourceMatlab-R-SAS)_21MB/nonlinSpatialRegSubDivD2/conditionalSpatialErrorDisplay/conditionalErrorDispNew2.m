diary off; clear; format compact;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase conditionalErrorDispNew2.log;
diary('conditionalErrorDispNew2.log');
!type  conditionalErrorDispNew2.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load zzAllDataWithCoordinateValues; 

tmpMinX=min(XX(:,1));
tmpMinY=min(XX(:,2));

XX(:,1)=XX(:,1)-tmpMinX+1;
XX(:,2)=XX(:,2)-tmpMinY+1;
clear tmpMinX tmpMinY;

maxX=max(XX(:,1))
minX=min(XX(:,1))
maxY=max(XX(:,2))
minY=min(XX(:,2))

[rowXX, colXX] = size(XX);
dataSize = rowXX

logN  = log(XX(:,4)+1);
R     = XX(:,5);
xF0   = XX(:,6);
xF1   = XX(:,7);
fracF = XX(:,3)./(1.0-XX(:,3)) ;
x     = XX(:,1);
y     = XX(:,2);

XX;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load bestParmsWithFinerPhi;
minLogLikelihood
clear FtoPower minLogLikelihood;

pwFracF   = ( (fracF    ).^fToPwr - 1.0 ) / fToPwr; 

B = zeros(dataSize,1);  
 
clear k;  
for k = 1:dataSize  
   if R(k) > beta(8)  
      B(k) = B(k) + beta(9)*log( R(k)/beta(8) ) ;  
   end  
end  
clear k;  
 
if logN == 0 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1; 
else 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1 ... 
   -beta(4) * ...  
    ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ...  
   -1.0./(1.0+exp(beta(5))) );  
end

load H4logit; clear X dim_org dsize lambda;
W = speye(dataSize) - phi*H_mat; clear H_mat;

dataSize
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e     = pwFracF - B;

gridSpatialError  = zeros(maxX,maxY); 
condeTmp  = zeros(dataSize,1);
count = 0; 
for j = 1:maxY
  for i = 1:maxX
    site = find( x(:) == i & y(:) == j );
    if isfinite(site)
      count = count + 1;  
      enbd = 0.0; 

      fb = find( x(:) == i-1 & y(:) == j   );
        if isfinite(fb); enbd = enbd + e(fb); end;
      ff = find( x(:) == i+1 & y(:) == j );
        if isfinite(ff); enbd = enbd + e(ff); end;
      fu = find( x(:) == i   & y(:) == j-1 );
        if isfinite(fu); enbd = enbd + e(fu); end;
      fd = find( x(:) == i   & y(:) == j+1 );
        if isfinite(fd); enbd = enbd + e(fd); end;

      %fprintf('pixel with (%3d, %3d), site = %d, fb = %d, ff = %d, fu = %d, fd = %d, enbd = %d\n', i, j, site, fb, ff, fu, fd, enbd);
      %condeTmp(site)  = e(site) - phi * ( e(fb) + e(ff) + e(fu) + e(fd) );
      condeTmp(site) = e(site) - phi*enbd ;
      gridSpatialError(i,j)  = condeTmp(site);
      clear fb ff fu fd enbd;

    else 
      gridSpatialError(i,j) = NaN;
      %fprintf('There is no pixel with (%3d, %3d)\n', i, j)
    end
    clear site;
  end
end

%figure,surf(1:maxY,1:maxX,gridSpatialError);
fprintf('\nData Size of conditional errors = %d\n', count)

condePre = zeros(maxY*maxY,1);
for j = 1:maxY
  for i = 1:maxX
    k = maxX*(j-1) + i;
      condePre(k)  = gridSpatialError(i,j);
  end
end

%conde = zeros(dataSize,1);
L  = find(isfinite(condePre(:,1)));
conde  = condePre(L,:);

format long;

%%% !!calculation check!! %%%
[mean(e), std(e)]

[mean(condeTmp), std(condeTmp)]
[mean(conde), std(conde)]

[minLogLikelihood2, I] = min(resv(:,6))

mseSpPreCalc = resv(I,5)
e'*W*e/dataSize

e'*e/dataSize
%mean(condeTmp)
condeTmp'*condeTmp/dataSize
condeTmp'*e/dataSize

checkMx = [(e'*W)', condeTmp];

%subplot(3,1,1); hist(e       , 30)
%subplot(3,1,2); hist((e'*W)' , 30)
%subplot(3,1,3); hist(condeTmp, 30)

% Raw data �Ƃ̍����`�F�b�N  ���ӏ���p���Ȃ��ꍇ
F = XX(:,3);
Fpred = 1 - 1./(1 + (1 + fToPwr*B).^(1/fToPwr) ); % ���肵�����ς̒l��F�̒l�ɕϊ�
%figure
%subplot(2,1,1); hist(F    , 30)
%subplot(2,1,2); hist(Fpred, 30)

Error = F - Fpred;
%figure, hist(F - Fpred, 30)

% Raw data �Ƃ̍����`�F�b�N  ���ӏ���p����ꍇ
% ���ς̒l�����ӂ̌덷�ŕ␳
Fpred2 = 1 - 1./(1 + (1 + fToPwr*(B + condeTmp)).^(1/fToPwr) );1
%figure
%subplot(2,1,1); hist(F     , 30)
%subplot(2,1,2); hist(Fpred2, 30)

Error2 = F - Fpred2;
[mean(Error), mean(Error2)]
[std(Error), std(Error2)]
[var(Error), var(Error2)]
[min(Error), min(Error2)]
[median(Error), median(Error2)]
[max(Error), max(Error2)]

%figure,
%subplot(2,1,1), hist(Error , 30)
%subplot(2,1,2), hist(Error2, 30)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gridF      = zeros(maxX,maxY); 
gridFpred  = zeros(maxX,maxY); 
gridFpred2 = zeros(maxX,maxY); 
gridError  = zeros(maxX,maxY); 
gridError2 = zeros(maxX,maxY); 

count2 = 0; 
for j = 1:maxY
  jr = maxY+1-j;
  for i = 1:maxX
    site = find( x(:) == i & y(:) == j );
    if isfinite(site)
      count2 = count2 + 1;  
      gridError(i,j)   = Error(site);
      gridError2(i,j)  = Error2(site);
      gridF(i,j)       = F(site);
      gridFpred(i,j)   = Fpred(site);
      gridFpred2(i,j)  = Fpred2(site);
    else 
      gridError(i,j)   = NaN;
      gridError2(i,j)  = NaN;
      gridF(i,j)       = NaN;
      gridFpred(i,j)   = NaN;
      gridFpred2(i,j)  = NaN;
      %fprintf('There is no pixel with (%3d, %3d)\n', i, j)
    end
    clear site;
  end
end
fprintf('\nData Size#2 of conditional errors = %d\n', count2)

mapE=colormap;
colormap(mapE);

%%% colortable manual-handling maybe needed %%%
figure,surf(1:maxY,1:maxX,gridError);

gridError2(1,maxY)  =min(Error);
gridError2(1,maxY-1)=max(Error);
colormap(mapE);
figure,surf(1:maxY,1:maxX,gridError2);

fColor=[zeros(1,101);0.0:0.01:1.0;zeros(1,101)]';
colormap(brighten(fColor,0.1));
mapF=colormap;
mapF(1,:)=[1.0,1.0,1.0];
colormap(mapF)

%%% colortable manual-handling maybe needed %%%
figure,surf(1:maxY,1:maxX,80*gridF)
figure,surf(1:maxY,1:maxX,80*gridFpred)
figure,surf(1:maxY,1:maxX,80*gridFpred2)

diary off;
