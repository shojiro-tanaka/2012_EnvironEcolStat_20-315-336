diary off; clear;

load 'tmpVariables.mat';


Ki = K0;
lengY
for p=2:lengY
   Ki(1,1) = K0(p,p); %k_ii
   Ki(1,2:colK) = K0(p,[1:(p-1),(p+1):colK]); %k_ia+k_ib
   Ki(2:rowK,1) = K0([1:(p-1),(p+1):rowK],p); %k_ai+k_bi
   Ki(2:p,2:p) = K0(1:(p-1),1:(p-1)); %K_aa
   Ki(2:p,(p+1):colK) = K0(1:(p-1),(p+1):colK); %K_ab
   Ki((p+1):rowK,2:p) = K0((p+1):rowK,1:(p-1)); %K_ba
   Ki((p+1):rowK,(p+1):colK) = ...
      K0((p+1):rowK,(p+1):colK); %K_bb
   sig12 = Ki(1,2:colK);
   Sig22 = Ki(2:rowK,2:colK);
   y_p   = y([1:(p-1),(p+1):lengY],1);
   mu_p  = y([1:(p-1),(p+1):lengY],2);
   p

   %%%
     cwd = pwd;
     cd(tempdir);
     pack
     cd(cwd)
   %%%

   mu1cond   = y(p,2) + sig12/Sig22*(y_p-mu_p)
   resvMuPos(p,:) = [p,mu1condMdfy,y(p,1),y(p,2),y(p,3:5)];
end

format long;
%resvMuPos

errorCondF = resvMuPos(:,3) - resvMuPos(:,2);
errorF = resvMuPos(:,3) -resvMuPos(:,4);

y0(resvMuPos(:,7),2)=errorCondF;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�O���b�h�쐬
errorSp = ones(maxY,maxX);
for j=1:maxY
   for i=1:maxX
      k=maxX*(j-1)+i;
      if k == maxX*(y-1)+x
         errorSp(j,i)=y0(k,2);
         else errorSp(j,i)=nan;
      end
   end
end

save 'resvSpErrorCond.mat' errorSp y0;

surf(1:sizeX,1:sizeY,errorSp);

mseCond = errorCondF'*errorCondF / length(errorCondF)
mseIndepen = errorF'*errorF / length(errorF)

diary off;
