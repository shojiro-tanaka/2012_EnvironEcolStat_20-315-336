clear;
diary off;

%%% (data load) %%%
load '../dataPreparation/H8697b.mat'; whos
x = X( :, 1);
y = X( :, 2);
F = X( :, 3);
N = X( :, 4);
R = X( :, 5);
clear X;
%%% /(data load) %%%


%%%  (forest areal rate == 0 or 1) %%%
L0 = F ==0.0; %sum(L0):159
L1 = F ==1.0; %sum(L1):1713
%%% /(forest areal rate == 0 or 1) %%%

%H8697�͗אڍs��
xF0  = H8697 * L0; 
xF1  = H8697 * L1;
tmp = sum(H8697,1); tmp = tmp';
clear L0 L1;

%check = [xF0, xF1, tmp];
%for i=1:dSizeAll
%  if (check(i,3)<check(i,1)) or (check(i,3)<check(i,2))
%    disp('error!')
%  end
%end

XX = [x, y, F, N, R, xF0, xF1];
clear x y F N R xF0 xF1;

%%%  (0 < forest areal rate < 1) %%%
L  = XX(:,3) < 1;
XX = XX(L,:); clear L;
L  = XX(:,3) > 0;
XX = XX(L,:); clear L;
dSize4logit   = length(XX) % (0 < F < 1)
dSizeAll
%%% /(0 < forest areal rate < 1) %%%

save 'zzAllDataWithCoordinateValues.mat' XX;
