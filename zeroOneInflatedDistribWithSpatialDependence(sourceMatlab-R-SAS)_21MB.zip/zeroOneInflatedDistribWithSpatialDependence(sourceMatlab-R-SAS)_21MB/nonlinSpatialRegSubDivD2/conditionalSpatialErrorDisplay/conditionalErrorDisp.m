diary off; clear;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase conditionalErrorDisp.log;
diary('conditionalErrorDisp.log');
!type  conditionalErrorDisp.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load zzAllDataWithCoordinateValues; 

tmpMinX=min(XX(:,1))
tmpMinY=min(XX(:,2))

XX(:,1)=XX(:,1)-tmpMinX+1;
XX(:,2)=XX(:,2)-tmpMinY+1;
clear tmpMinX tmpMinY;

maxX=max(XX(:,1))
minX=min(XX(:,1))
maxY=max(XX(:,2))
minY=min(XX(:,2))

[rowXX, colXX] = size(XX);
dataSize = rowXX

logN  = log(XX(:,4)+1);
R     = XX(:,5);
xF0   = XX(:,6);
xF1   = XX(:,7);
fracF = XX(:,3)./(1.0-XX(:,3)) ;
x     = XX(:,1);
y     = XX(:,2);

clear XX;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load bestParmsWithFinerPhi;
minLogLikelihood
clear FtoPower minLogLikelihood;

pwFracF   = ( (fracF    ).^fToPwr - 1.0 ) / fToPwr; 

B = zeros(dataSize,1);  
 
clear k;  
for k = 1:dataSize  
   if R(k) > beta(8)  
      B(k) = B(k) + beta(9)*log( R(k)/beta(8) ) ;  
   end  
end  
clear k;  
 
if logN == 0 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1; 
else 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1 ... 
   -beta(4) * ...  
    ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ...  
   -1.0./(1.0+exp(beta(5))) );  
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y0 = zeros(dataSize,4);

y0(:,1) = pwFracF;
y0(:,2) = B;
y0(:,3) = x;
y0(:,4) = y;

yInd = find( ~isnan(y0(:,2)) );
y = [y0(yInd,1:4), yInd]; 
clear yInd;
lengY = length(y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�אڍs��̃��[�h
load 'H4logit.mat'; %whos
clear dim_org lambda X;
K0    = inv(speye(dataSize) - phi*H_mat);
[rowK, colK] = size(K0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if rowK ~= lengY 
   disp('error')
end

resvMuPos = zeros(lengY,7);

sig12 = K0(1,2:colK);
Sig22 = K0(2:rowK,2:colK);
y_1   = y(2:lengY,1);
mu_1  = y(2:lengY,2);
mu1cond  = y(1,2) + sig12/Sig22*(y_1-mu_1)
resvMuPos(1,:) = [1,mu1cond,y(1,1),y(1,2),y(1,3:5)];
clear sig12 Sig22 y_1 mu_1 mu1cond;

save 'tmpVariables.mat' K0 y y0 resvMuPos rowK colK maxY maxX lengY;
Ki = K0;
lengY
for p=2:lengY
   Ki(1,1) = K0(p,p); %k_ii
   Ki(1,2:colK) = K0(p,[1:(p-1),(p+1):colK]); %k_ia+k_ib
   Ki(2:rowK,1) = K0([1:(p-1),(p+1):rowK],p); %k_ai+k_bi
   Ki(2:p,2:p) = K0(1:(p-1),1:(p-1)); %K_aa
   Ki(2:p,(p+1):colK) = K0(1:(p-1),(p+1):colK); %K_ab
   Ki((p+1):rowK,2:p) = K0((p+1):rowK,1:(p-1)); %K_ba
   Ki((p+1):rowK,(p+1):colK) = ...
      K0((p+1):rowK,(p+1):colK); %K_bb
   sig12 = Ki(1,2:colK);
   Sig22 = Ki(2:rowK,2:colK);
   y_p   = y([1:(p-1),(p+1):lengY],1);
   mu_p  = y([1:(p-1),(p+1):lengY],2);
   p
   mu1cond   = y(p,2) + sig12/Sig22*(y_p-mu_p)
   resvMuPos(p,:) = [p,mu1condMdfy,y(p,1),y(p,2),y(p,3:5)];
end

format long;
%resvMuPos

errorCondF = resvMuPos(:,3) - resvMuPos(:,2);
errorF = resvMuPos(:,3) -resvMuPos(:,4);

y0(resvMuPos(:,7),2)=errorCondF;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�O���b�h�쐬
errorSp = ones(maxY,maxX);
for j=1:maxY
   for i=1:maxX
      k=maxX*(j-1)+i;
      if k == maxX*(y-1)+x
         errorSp(j,i)=y0(k,2);
         else errorSp(j,i)=nan;
      end
   end
end

save 'resvSpErrorCond.mat' errorSp y0;

surf(1:sizeX,1:sizeY,errorSp);

mseCond = errorCondF'*errorCondF / length(errorCondF)
mseIndepen = errorF'*errorF / length(errorF)

diary off;
