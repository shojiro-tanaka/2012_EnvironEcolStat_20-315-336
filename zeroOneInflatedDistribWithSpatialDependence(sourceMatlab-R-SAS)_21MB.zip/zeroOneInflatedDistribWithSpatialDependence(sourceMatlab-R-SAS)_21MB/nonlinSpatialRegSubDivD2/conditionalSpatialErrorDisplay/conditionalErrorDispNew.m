diary off; clear; format compact;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase conditionalErrorDispNew.log;
diary('conditionalErrorDispNew.log');
!type  conditionalErrorDispNew.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load zzAllDataWithCoordinateValues; 

tmpMinX=min(XX(:,1));
tmpMinY=min(XX(:,2));

XX(:,1)=XX(:,1)-tmpMinX+1;
XX(:,2)=XX(:,2)-tmpMinY+1;
clear tmpMinX tmpMinY;

maxX=max(XX(:,1))
minX=min(XX(:,1))
maxY=max(XX(:,2))
minY=min(XX(:,2))

[rowXX, colXX] = size(XX);
dataSize = rowXX

logN  = log(XX(:,4)+1);
R     = XX(:,5);
xF0   = XX(:,6);
xF1   = XX(:,7);
fracF = XX(:,3)./(1.0-XX(:,3)) ;
x     = XX(:,1);
y     = XX(:,2);

clear XX;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load bestParmsWithFinerPhi;
minLogLikelihood
clear FtoPower minLogLikelihood;

pwFracF   = ( (fracF    ).^fToPwr - 1.0 ) / fToPwr; 

B = zeros(dataSize,1);  
 
clear k;  
for k = 1:dataSize  
   if R(k) > beta(8)  
      B(k) = B(k) + beta(9)*log( R(k)/beta(8) ) ;  
   end  
end  
clear k;  
 
if logN == 0 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1; 
else 
B = B ... 
   +beta(1) ...  
   +beta(2)*xF0 + beta(3)*xF1 ... 
   -beta(4) * ...  
    ( 1.0./(1.0+exp(beta(5)-beta(6)*(logN.^beta(7)))) ...  
   -1.0./(1.0+exp(beta(5))) );  
end

load H4logit; clear X dim_org dsize lambda;
W = speye(dataSize) - phi*H_mat; clear H_mat;

dataSize
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
e     = pwFracF - B;

gridSpatialError  = zeros(maxX,maxY); 
condeTmp  = zeros(dataSize,1);
count = 0; 
for j = 1:maxY
  newY = (maxY+1) -j;
  for i = 1:maxX
    site = find( x(:) == i & y(:) == j );
    if isfinite(site)
      count = count + 1;  
      enbd = 0.0; 

      fb = find( x(:) == i-1 & y(:) == j   );
        if isfinite(fb); enbd = enbd + e(fb); end;
      ff = find( x(:) == i+1 & y(:) == j );
        if isfinite(ff); enbd = enbd + e(ff); end;
      fu = find( x(:) == i   & y(:) == j-1 );
        if isfinite(fu); enbd = enbd + e(fu); end;
      fd = find( x(:) == i   & y(:) == j+1 );
        if isfinite(fd); enbd = enbd + e(fd); end;

      %fprintf('pixel with (%3d, %3d), site = %d, fb = %d, ff = %d, fu = %d, fd = %d, enbd = %d\n', i, j, site, fb, ff, fu, fd, enbd);
      %condeTmp(site)  = e(site) - phi * ( e(fb) + e(ff) + e(fu) + e(fd) );
      condeTmp(site) = e(site) - phi*enbd ;
      gridSpatialError(i,j)  = condeTmp(site);
      clear fb ff fu fd enbd;

    else 
      gridSpatialError(i,j) = NaN;
      %fprintf('There is no pixel with (%3d, %3d)\n', i, j)
    end
    clear site;
  end
end

fprintf('\nData Size of conditional errors = %d\n', count)

format long;

figure,h=surf(1:maxY,1:maxX,gridSpatialError);
%map = colormap;
%map(1,:)=[1.0,1.0,1.0];
%colormap(map);
%figure,image(gridSpatialError)

%%% !!calculation check!! %%%
condePre = zeros(maxY*maxY,1);
for j = 1:maxY
  for i = 1:maxX
    k = maxX*(j-1) + i;
      condePre(k)  = gridSpatialError(i,j);
  end
end

%conde = zeros(dataSize,1);
L  = find(isfinite(condePre(:,1)));
conde  = condePre(L,:);

[mean(e), std(e)]

[mean(condeTmp), std(condeTmp)]
[mean(conde), std(conde)]

[minLogLikelihood2, I] = min(resv(:,6))

mseSpPreCalc = resv(I,5)
e'*W*e/dataSize

e'*e/dataSize
%mean(condeTmp)
condeTmp'*condeTmp/dataSize
condeTmp'*e/dataSize

checkMx = [(e'*W)', condeTmp];

diary off;
